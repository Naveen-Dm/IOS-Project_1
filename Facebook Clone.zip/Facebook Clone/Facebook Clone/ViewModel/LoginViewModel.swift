//
//  LoginViewModel.swift
//  login mvvm final
//
//  Created by Naveen Madhu on 19/05/22.
//


import Foundation

class LoginViewModel {
    //Here our model notify that was updated
    private var credentials : LoginCredentials = LoginCredentials() {
        didSet {
            username = credentials.username
            password = credentials.password
        }
    }
    
    var username = ""
    var password = ""
    //Login credentials
    let usernameCheck = "Naveen"
    let passwordCheck = "abc123"
    //Error messages
    let loginSuccess = "Login Successful."
    let invalidLogin = "Invalid Username or Password."
    private let textfieldsEmpty = "Please provide username and password."
    private let usernameIsEmpty = "Username field is empty."
    private let passwordIsEmpty = "Password field is empty."
    
    var credentialsInputErrorMessage: Observable<String> = Observable("")
    var isUsernameTextFieldHighLighted: Observable<Bool> = Observable(false)
    var isPasswordTextFieldHighLighted: Observable<Bool> = Observable(false)
    var errorMessage: Observable<String?> = Observable(nil)
    
    //Here we update our model
    func updateCredentials(username: String, password: String) {
        credentials.username = username
        credentials.password = password
    }
    
    //Checks the user credentials input
    func credentialsInput() -> CredentialsInputStatus {
        if username.isEmpty && password.isEmpty {
            credentialsInputErrorMessage.value = textfieldsEmpty
            return.Incorrect
        }
        if username.isEmpty {
            credentialsInputErrorMessage.value = usernameIsEmpty
            isUsernameTextFieldHighLighted.value = true
            return.Incorrect
        }
        if password.isEmpty {
            credentialsInputErrorMessage.value = passwordIsEmpty
            isPasswordTextFieldHighLighted.value = true
            return.Incorrect
        }
        return.Correct
    }
}

extension LoginViewModel {
    enum CredentialsInputStatus {
        case Correct
        case Incorrect
    }
}
