//
//  SearchViewController.swift
//  Constraints2
//
//  Created by Naveen Madhu on 05/09/22.
//

import UIKit

class SearchViewController: UIViewController {

    private var searchViewModel: SearchViewModel = SearchViewModel()

    var searching = false

    // UI Elements
    private let searchView: UIView = {
        let searchView = UIView()
        searchView.translatesAutoresizingMaskIntoConstraints = false
        searchView.backgroundColor = .white
        return searchView
    }()

    private let backButton: UIButton = {
        let backButton = UIButton()
        backButton.setImage(UIImage(systemName: "arrow.backward"), for: .normal)
        backButton.translatesAutoresizingMaskIntoConstraints = false
        return backButton
    }()

    private let searchBar: UISearchBar = {
        let searchBar = UISearchBar()
        searchBar.translatesAutoresizingMaskIntoConstraints = false
        searchBar.placeholder = "Search..."
        searchBar.showsCancelButton = true
        return searchBar
    }()

    private let searchTableView: UITableView = {
        let searchTableView = UITableView()
        searchTableView.register(SearchTableViewCell.classForCoder(), forCellReuseIdentifier: "searchCell")
        searchTableView.translatesAutoresizingMaskIntoConstraints = false
        searchTableView.backgroundColor = .white
//        searchTableView.isHidden = true
        return searchTableView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        initialSetup()
        addConstraints()
    }

    private func initialSetup() {
        view.backgroundColor = .systemGray6
        view.addSubview(searchView)
        searchView.addSubview(backButton)
        searchView.addSubview(searchBar)
        searchBar.delegate = self

        view.addSubview(searchTableView)
        searchTableView.delegate = self
        searchTableView.dataSource = self

        buttonActions()
    }

    private func buttonActions() {
        backButton.addTarget(self, action: #selector(gotoMainPage), for: .touchUpInside)
    }

    @objc private func gotoMainPage() {
        let mainPage = storyboard?.instantiateViewController(withIdentifier: "FBViewController") as! FBViewController
        self.present(mainPage, animated: true)
    }

    private func addConstraints() {
        var constraints = [NSLayoutConstraint]()

        constraints.append(searchView.leadingAnchor.constraint(equalTo: view.leadingAnchor))
        constraints.append(searchView.trailingAnchor.constraint(equalTo: view.trailingAnchor))
        constraints.append(searchView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor))
        constraints.append(searchView.heightAnchor.constraint(equalToConstant: 60.0))

        constraints.append(backButton.topAnchor.constraint(equalTo: searchView.topAnchor))
        constraints.append(backButton.leadingAnchor.constraint(equalTo: searchView.leadingAnchor))
        constraints.append(backButton.bottomAnchor.constraint(equalTo: searchView.bottomAnchor))
        constraints.append(backButton.widthAnchor.constraint(equalToConstant: 40.0))

        constraints.append(searchBar.leadingAnchor.constraint(equalTo: backButton.trailingAnchor))
        constraints.append(searchBar.trailingAnchor.constraint(equalTo: searchView.trailingAnchor))
        constraints.append(searchBar.topAnchor.constraint(equalTo: searchView.topAnchor))
        constraints.append(searchBar.bottomAnchor.constraint(equalTo: searchView.bottomAnchor))

        constraints.append(searchTableView.leadingAnchor.constraint(equalTo: searchView.leadingAnchor))
        constraints.append(searchTableView.trailingAnchor.constraint(equalTo: searchView.trailingAnchor))
        constraints.append(searchTableView.topAnchor.constraint(equalTo: searchView.bottomAnchor, constant: 5.0))
        constraints.append(searchTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor))

        NSLayoutConstraint.activate(constraints)
    }
}


extension SearchViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if searching {
//            return searchViewModel.searchedName.count
//        } else {
//            return searchViewModel.nameData.count
//        }
        
        if searching {
            return searchViewModel.searched.count
        } else {
            return searchViewModel.searchList.count
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let searchCell = tableView.dequeueReusableCell(withIdentifier: "searchCell", for: indexPath) as! SearchTableViewCell
        
        if searching {
            searchCell.profileImageView.image = UIImage(named: searchViewModel.searched[indexPath.row].searchImage)
            searchCell.searchCellLabel.text = searchViewModel.searched[indexPath.row].searchName
        } else {
            searchCell.profileImageView.image = UIImage(named: searchViewModel.searchList[indexPath.row].searchImage)
            searchCell.searchCellLabel.text = searchViewModel.searchList[indexPath.row].searchName
        }
        
//        if searching {
//            searchCell.searchCellLabel.text = searchViewModel.searchedName[indexPath.row]
//            searchCell.profileImageView.image = searchViewModel.searchedImage[indexPath.row]
//        } else {
//            searchCell.searchCellLabel.text = searchViewModel.nameData[indexPath.row]
//            searchCell.profileImageView.image = searchViewModel.logoImage[indexPath.row]
//        }
        
        searchCell.selectionStyle = .none
        return searchCell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}

extension SearchViewController: UISearchBarDelegate {

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//        searchTableView.isHidden = false
//        searchViewModel.searchedName = searchViewModel.nameData.filter({$0.prefix(searchText.count) == searchText})
//        searching = true
//        searchTableView.reloadData()
        
        if !searchText.isEmpty {
            searching = true
            searchViewModel.searched.removeAll()
            for name in searchViewModel.searchList {
                if name.searchName.uppercased().contains(searchText.uppercased()) {
                    searchViewModel.searched.append(name)
                }
            }
        } else {
            searching = false
            searchViewModel.searched.removeAll()
            searchViewModel.searched = searchViewModel.searchList
        }
        searchTableView.reloadData()
    }
    
}
    




//            searchViewModel.searchList = searchViewModel.searchList.filter{
//                $0.searchName.contains(searchText)
//            }
