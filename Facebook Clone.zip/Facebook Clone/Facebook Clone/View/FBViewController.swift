//
//  ViewController.swift
//  Constraints2
//
//  Created by Naveen Madhu on 25/08/22.
//

import UIKit

class FBViewController: UIViewController {
    
    // Properties
    private var collectionViewModel: CollectionViewModel = CollectionViewModel()
    private var postViewModel: PostViewModel = PostViewModel()
    private var dropDownViewModel: DropDownViewModel = DropDownViewModel()
    private var collection: UICollectionView!
    private let defaults = UserDefaults.standard
    private var isClicked = false
 
    // UI Elements
    private let topView: UIView = {
        let topView = UIView()
        topView.translatesAutoresizingMaskIntoConstraints = false
        topView.backgroundColor = .white
        return topView
    }()
    
    private let firstLabel: UILabel = {
        let firstLabel = UILabel()
        firstLabel.translatesAutoresizingMaskIntoConstraints = false
        firstLabel.text = "facebook"
        firstLabel.textColor = .systemBlue
        firstLabel.font = UIFont(name: "HelveticaNeue-Bold", size: 35)
        return firstLabel
    }()
    
    private let stackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 10
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    private let plusButton: UIButton = {
        let plusButton = UIButton()
        plusButton.setImage(UIImage(systemName: "plus"), for: .normal)
        plusButton.backgroundColor = .systemGray5
        plusButton.layer.cornerRadius = 20.0
        plusButton.translatesAutoresizingMaskIntoConstraints = false
        return plusButton
    }()

    private let searchButton: UIButton = {
        let searchButton = UIButton()
        searchButton.setImage(UIImage(systemName: "magnifyingglass"), for: .normal)
        searchButton.backgroundColor = .systemGray5
        searchButton.layer.cornerRadius = 20.0
        searchButton.translatesAutoresizingMaskIntoConstraints = false
        return searchButton
    }()

    private let logoutButton: UIButton = {
        let logoutButton = UIButton()
        logoutButton.setImage(UIImage(systemName: "rectangle.portrait.and.arrow.right"), for: .normal)
        logoutButton.backgroundColor = .systemGray5
        logoutButton.layer.cornerRadius = 20.0
        logoutButton.translatesAutoresizingMaskIntoConstraints = false
        return logoutButton
    }()
    
    private let navStackView: UIStackView = {
        let navStackView = UIStackView()
        navStackView.axis = .horizontal
        navStackView.distribution = .fillEqually
        navStackView.spacing = 10
        navStackView.backgroundColor = .white
        navStackView.translatesAutoresizingMaskIntoConstraints = false
        return navStackView
    }()
    
    private let homeButton: UIButton = {
        let homeButton = UIButton()
//        constantButtons(button: homeButton, title: "", imageName: "house")
        homeButton.setImage(UIImage(systemName: "house"), for: .normal)
        homeButton.translatesAutoresizingMaskIntoConstraints = false
        return homeButton
    }()
    
    private let watchButton: UIButton = {
        let watchButton = UIButton()
        watchButton.setImage(UIImage(systemName: "play.tv"), for: .normal)
        watchButton.translatesAutoresizingMaskIntoConstraints = false
        return watchButton
    }()
    
    private let musicButton: UIButton = {
        let musicButton = UIButton()
        musicButton.setImage(UIImage(systemName: "music.house"), for: .normal)
        musicButton.translatesAutoresizingMaskIntoConstraints = false
        return musicButton
    }()
    
    private let notificationButton: UIButton = {
        let notificationButton = UIButton()
        notificationButton.setImage(UIImage(systemName: "bell"), for: .normal)
        notificationButton.translatesAutoresizingMaskIntoConstraints = false
        return notificationButton
    }()
    
    private let menuButton: UIButton = {
        let menuButton = UIButton()
        menuButton.setImage(UIImage(systemName: "line.3.horizontal"), for: .normal)
        menuButton.translatesAutoresizingMaskIntoConstraints = false
        return menuButton
    }()
    
    private let searchView: UIView = {
        let searchView = UIView()
        searchView.translatesAutoresizingMaskIntoConstraints = false
        searchView.backgroundColor = .white
        return searchView
    }()
    
    private let iconImageView: UIImageView = {
        let iconImageView = UIImageView()
        iconImageView.backgroundColor = .systemGray5
        iconImageView.layer.cornerRadius = 25.0
        iconImageView.contentMode = .scaleToFill;
        iconImageView.image = UIImage(named: "icon image")
        iconImageView.clipsToBounds = true
        iconImageView.translatesAutoresizingMaskIntoConstraints = false
        return iconImageView
    }()

    private let firstTextField: UITextField = {
        var firstTextField = UITextField()
        firstTextField.translatesAutoresizingMaskIntoConstraints = false
        firstTextField.placeholder = "Write something here..."
        firstTextField.backgroundColor = .systemGray6
        firstTextField.setPadding()
        firstTextField.layer.cornerRadius = 32.0
        return firstTextField
    }()
    
    private let imageButton: UIButton = {
        let imageButton = UIButton()
        imageButton.setImage(UIImage(systemName: "photo.fill"), for: .normal)
        imageButton.translatesAutoresizingMaskIntoConstraints = false
        return imageButton
    }()
    
    private let storyLabel: UILabel = {
        let storyLabel = UILabel()
        storyLabel.translatesAutoresizingMaskIntoConstraints = false
        storyLabel.text = "Stories"
        storyLabel.textAlignment = .center
        storyLabel.backgroundColor = .white
        storyLabel.font = UIFont(name: "HelveticaNeue", size: 20)
        return storyLabel
    }()
    
    private let storyView: UIView = {
        let storyView = UIView()
        storyView.translatesAutoresizingMaskIntoConstraints = false
        return storyView
    }()
    
    private let postTableView: UITableView = {
        let postTableView = UITableView()
        postTableView.register(PostTableViewCell.classForCoder(), forCellReuseIdentifier: "cell")
        postTableView.translatesAutoresizingMaskIntoConstraints = false
        postTableView.backgroundColor = .white
        return postTableView
    }()
    
    private let dropDownTableView: UITableView = {
        let dropDownTableView = UITableView()
        dropDownTableView.register(DropDownTableViewCell.classForCoder(), forCellReuseIdentifier: "CELL")
        dropDownTableView.translatesAutoresizingMaskIntoConstraints = false
        dropDownTableView.backgroundColor = .blue
        return dropDownTableView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        initialSetup()
        
    }
    
    private func initialSetup() {
        view.backgroundColor = .gray
        view.addSubview(topView)
        topView.addSubview(firstLabel)
        
        topView.addSubview(stackView)
        stackView.addArrangedSubview(plusButton)
        stackView.addArrangedSubview(searchButton)
        stackView.addArrangedSubview(logoutButton)
        
        view.addSubview(navStackView)
        navStackView.addArrangedSubview(homeButton)
        navStackView.addArrangedSubview(watchButton)
        navStackView.addArrangedSubview(musicButton)
        navStackView.addArrangedSubview(notificationButton)
        navStackView.addArrangedSubview(menuButton)
        
        view.addSubview(postTableView)
        setupTableView()

        postTableView.addSubview(searchView)
        searchView.addSubview(iconImageView)
        searchView.addSubview(firstTextField)
        searchView.addSubview(imageButton)
        firstTextField.delegate = self
        
        view.addSubview(dropDownTableView)
        dropDownTableView.isHidden = true
        dropDownTable()
        
        postTableView.addSubview(storyView)
        storyView.addSubview(storyLabel)
        setupCollectionView()
        
        self.hideKeyboardWhenTappedAround()
        buttonActions()
        addConstraints()
    }
    
    func constantButtons(button: UIButton, title: String? = "", imageName: String? = "")  {
        if title != "" {
            button.setTitle(title, for: .normal)
            button.setImage(UIImage(systemName: imageName!), for: .normal)
        }
        button.translatesAutoresizingMaskIntoConstraints = false
    }
    
    // Performs button action
    private func buttonActions() {
        plusButton.addTarget(self, action: #selector(plusButtonPressed(_:)), for: .touchUpInside)
        searchButton.addTarget(self, action: #selector(gotoSearchPage), for: .touchUpInside)
        logoutButton.addTarget(self, action: #selector(logoutButtonPressed(_:)), for: .touchUpInside)
        homeButton.addTarget(self, action: #selector(homeButtonPressed(_:)), for: .touchUpInside)
    }
    
    // To show drop down menu
    @objc func plusButtonPressed(_ sender: UITapGestureRecognizer) {
        if dropDownTableView.isHidden {
            animate(toggle: true)
        } else {
            animate(toggle: false)
        }
    }
    
    func animate(toggle: Bool) {
        if toggle {
            UIView.animate(withDuration: 0.5) {
                self.dropDownTableView.isHidden = false
            }
        } else {
            UIView.animate(withDuration: 0.5) {
                self.dropDownTableView.isHidden = true
            }
        }
    }
    
    // To remove the user from DB
    @objc func logoutButtonPressed(_ sender: UITapGestureRecognizer) {
        defaults.removeObject(forKey: "keyUserName")
        defaults.removeObject(forKey: "keyPassword")
        defaults.synchronize()
        showAlert()
    }
    
    private func showAlert() {
        let alert = UIAlertController(title: "Logout", message: "Are You Sure?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        alert.addAction(UIAlertAction(title: "OK", style: .destructive, handler: {action in
            self.gotoLoginPage()
        }))
        present(alert, animated: true)
    }

    private func gotoLoginPage() {
        let loginPage = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.present(loginPage, animated: true)
    }
    
    @objc func homeButtonPressed(_ sender: UITapGestureRecognizer) {
        if isClicked {
            isClicked = false
            homeButton.setImage(UIImage(systemName: "house.fill"), for: .normal)
        } else {
            isClicked = true
            homeButton.setImage(UIImage(systemName: "house"), for: .normal)
        }
    }
    
    @objc private func gotoSearchPage() {
        let searchPage = storyboard?.instantiateViewController(withIdentifier: "SearchViewController") as! SearchViewController
        self.present(searchPage, animated: true)
    }
    
    // MARK: Adding constraints to UI elements
    private func addConstraints() {
        var constraints = [NSLayoutConstraint]()
        
        constraints.append(topView.leadingAnchor.constraint(equalTo: view.leadingAnchor))
        constraints.append(topView.trailingAnchor.constraint(equalTo: view.trailingAnchor))
        constraints.append(topView.topAnchor.constraint(equalTo: view.topAnchor))
        constraints.append(topView.heightAnchor.constraint(equalToConstant: 90.0))
               
        constraints.append(firstLabel.leadingAnchor.constraint(equalTo: topView.leadingAnchor, constant: 10.0))
        constraints.append(firstLabel.trailingAnchor.constraint(equalTo: topView.trailingAnchor, constant: -200.0))
        constraints.append(firstLabel.topAnchor.constraint(equalTo: topView.topAnchor, constant: 40.0))
        constraints.append(topView.heightAnchor.constraint(equalToConstant: 150.0))
        
        constraints.append(stackView.leadingAnchor.constraint(equalTo: firstLabel.trailingAnchor, constant: 50.0))
        constraints.append(stackView.trailingAnchor.constraint(equalTo: topView.trailingAnchor, constant: -10.0))
        constraints.append(stackView.topAnchor.constraint(equalTo: topView.topAnchor, constant: 40.0))
        constraints.append(stackView.heightAnchor.constraint(equalToConstant: 42.0))
        
        constraints.append(navStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor))
        constraints.append(navStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor))
        constraints.append(navStackView.topAnchor.constraint(equalTo: topView.bottomAnchor))
        constraints.append(navStackView.heightAnchor.constraint(equalToConstant: 50.0))
        
        constraints.append(searchView.leadingAnchor.constraint(equalTo: view.leadingAnchor))
        constraints.append(searchView.trailingAnchor.constraint(equalTo: view.trailingAnchor))
        constraints.append(searchView.topAnchor.constraint(equalTo: postTableView.topAnchor, constant: 1.0))
        constraints.append(searchView.heightAnchor.constraint(equalToConstant: 80.0))

        constraints.append(iconImageView.leadingAnchor.constraint(equalTo: searchView.leadingAnchor, constant: 5.0))
        constraints.append(iconImageView.topAnchor.constraint(equalTo: searchView.topAnchor, constant: 15.0))
        constraints.append(iconImageView.widthAnchor.constraint(equalToConstant: 50))
        constraints.append(iconImageView.heightAnchor.constraint(equalToConstant: 50))

        constraints.append(firstTextField.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 5.0))
        constraints.append(firstTextField.trailingAnchor.constraint(equalTo: searchView.trailingAnchor, constant: -50.0))
        constraints.append(firstTextField.topAnchor.constraint(equalTo: searchView.topAnchor, constant: 10.0))
        constraints.append(firstTextField.heightAnchor.constraint(equalToConstant: 60.0))

        constraints.append(imageButton.leadingAnchor.constraint(equalTo: firstTextField.trailingAnchor, constant: 5.0))
        constraints.append(imageButton.topAnchor.constraint(equalTo: firstTextField.topAnchor, constant: 10.0))
        constraints.append(imageButton.widthAnchor.constraint(equalToConstant: 40.0))
        constraints.append(imageButton.heightAnchor.constraint(equalToConstant: 40.0))
        
        constraints.append(storyLabel.leadingAnchor.constraint(equalTo: searchView.leadingAnchor))
        constraints.append(storyLabel.trailingAnchor.constraint(equalTo: searchView.trailingAnchor))
        constraints.append(storyLabel.topAnchor.constraint(equalTo: searchView.bottomAnchor, constant: 20.0))
        constraints.append(storyLabel.heightAnchor.constraint(equalToConstant: 50.0))
        
        constraints.append(storyView.leadingAnchor.constraint(equalTo: storyLabel.leadingAnchor))
        constraints.append(storyView.trailingAnchor.constraint(equalTo: storyLabel.trailingAnchor))
        constraints.append(storyView.topAnchor.constraint(equalTo: storyLabel.bottomAnchor, constant: 1.0))
        constraints.append(storyView.heightAnchor.constraint(equalToConstant: 250.0))

        NSLayoutConstraint.activate(constraints)
    }
    
    private func setupCollectionView() {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal

        collection = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collection.backgroundColor = .white
        collection.translatesAutoresizingMaskIntoConstraints = false
        collection.contentInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        storyView.addSubview(collection)

        collection.topAnchor.constraint(equalTo: storyView.topAnchor, constant: 1.0).isActive = true
        collection.leadingAnchor.constraint(equalTo: storyView.leadingAnchor).isActive = true
        collection.trailingAnchor.constraint(equalTo: storyView.trailingAnchor).isActive = true
        collection.heightAnchor.constraint(equalToConstant: 250).isActive = true

        collection.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "CELL")
        collection.dataSource = self
        collection.delegate = self
    }

    private func setupTableView() {
        postTableView.delegate = self
        postTableView.dataSource = self

        NSLayoutConstraint.activate([
            postTableView.leadingAnchor.constraint(equalTo: navStackView.leadingAnchor),
            postTableView.trailingAnchor.constraint(equalTo: navStackView.trailingAnchor),
            postTableView.topAnchor.constraint(equalTo: navStackView.bottomAnchor, constant: 1.0),
            postTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)

        ])
    }
    
    private func dropDownTable() {
        dropDownTableView.delegate = self
        dropDownTableView.dataSource = self

        NSLayoutConstraint.activate([
            dropDownTableView.leadingAnchor.constraint(equalTo: plusButton.leadingAnchor),
            dropDownTableView.topAnchor.constraint(equalTo: plusButton.bottomAnchor, constant: 5.0),
            dropDownTableView.heightAnchor.constraint(equalToConstant: 120.0),
            dropDownTableView.widthAnchor.constraint(equalToConstant: 100.0)

        ])
    }
}

// MARK: Collection view delegate and datasource
extension FBViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width * 0.30, height: 230)
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collectionViewModel.storyList.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let stories = collectionViewModel.storyList[indexPath.row]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CELL", for: indexPath)

        let imageView = UIImageView(image: UIImage(named: stories.storyImage))
        cell.addSubview(imageView)
        imageView.clipsToBounds = true
        imageView.contentMode = .scaleAspectFill
        imageView.layer.cornerRadius = 10
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.topAnchor.constraint(equalTo: cell.topAnchor, constant: 5).isActive = true
        imageView.leadingAnchor.constraint(equalTo: cell.leadingAnchor).isActive = true
        imageView.trailingAnchor.constraint(equalTo: cell.trailingAnchor).isActive = true
        imageView.bottomAnchor.constraint(equalTo: cell.bottomAnchor, constant: -5).isActive = true
        
        let label = UILabel()
        imageView.addSubview(label)
        label.text = stories.storyName
        label.textColor = .white
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 15)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.topAnchor.constraint(equalTo: imageView.topAnchor, constant: 180.0).isActive = true
        label.leadingAnchor.constraint(equalTo: imageView.leadingAnchor, constant: 5.0).isActive = true
        label.trailingAnchor.constraint(equalTo: imageView.trailingAnchor).isActive = true
        label.bottomAnchor.constraint(equalTo: imageView.bottomAnchor, constant: -5).isActive = true
        return cell
    }
}

// MARK: Table view delegate and data source
extension FBViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == postTableView {
            return postViewModel.postList.count
        }
        return dropDownViewModel.menuList.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == postTableView {
            let posts = postViewModel.postList[indexPath.row]
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PostTableViewCell
            cell.tag = indexPath.row
            cell.selectionStyle = .none
            cell.nameInitialization(item: posts)
            cell.imageInitialization(post: posts)
            return cell
        } else {
            
            
            let menus = dropDownViewModel.menuList[indexPath.row]
            let dropdownCell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! DropDownTableViewCell
            if (indexPath.row == 0) {
                dropdownCell.addSubview(dropdownCell.postPlusButton)
                
                dropdownCell.postPlusButton.topAnchor.constraint(equalTo: dropdownCell.topAnchor, constant: 5.0).isActive = true
                dropdownCell.postPlusButton.leadingAnchor.constraint(equalTo: dropdownCell.dropDownMenu.trailingAnchor, constant: 1.0).isActive = true
                dropdownCell.postPlusButton.trailingAnchor.constraint(equalTo: dropdownCell.trailingAnchor).isActive = true
                dropdownCell.postPlusButton.heightAnchor.constraint(equalToConstant: 35).isActive = true
                
            } else if (indexPath.row == 1) {
                dropdownCell.addSubview(dropdownCell.storyButton)
                
                dropdownCell.storyButton.topAnchor.constraint(equalTo: dropdownCell.topAnchor, constant: 5.0).isActive = true
                dropdownCell.storyButton.leadingAnchor.constraint(equalTo: dropdownCell.dropDownMenu.trailingAnchor, constant: 1.0).isActive = true
                dropdownCell.storyButton.trailingAnchor.constraint(equalTo: dropdownCell.trailingAnchor).isActive = true
                dropdownCell.storyButton.heightAnchor.constraint(equalToConstant: 35).isActive = true
                
            } else {
                dropdownCell.addSubview(dropdownCell.savedButton)
                
                dropdownCell.savedButton.topAnchor.constraint(equalTo: dropdownCell.topAnchor, constant: 5.0).isActive = true
                dropdownCell.savedButton.leadingAnchor.constraint(equalTo: dropdownCell.dropDownMenu.trailingAnchor, constant: 1.0).isActive = true
                dropdownCell.savedButton.trailingAnchor.constraint(equalTo: dropdownCell.trailingAnchor).isActive = true
                dropdownCell.savedButton.heightAnchor.constraint(equalToConstant: 35).isActive = true
            }
           
            dropdownCell.dropDownMenu.text = menus.menuName
            dropdownCell.selectionStyle = .none
            return dropdownCell
        }
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var height:CGFloat = CGFloat()
        if tableView == postTableView {
            if indexPath.row == 0 {
                height = 400
            }
            else {
                height = 440
            }
            return height
        }
        return 40
    }
}

extension FBViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        firstTextField.resignFirstResponder()
        return true
    }
}

extension UITextField {
    func setPadding() {
        let padding = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: self.frame.height))
        self.leftView = padding
        self.leftViewMode = .always
    }
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
