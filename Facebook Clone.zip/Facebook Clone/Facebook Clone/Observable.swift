//
//  Observable.swift
//  login mvvm final
//
//  Created by Naveen Madhu on 19/05/22.
//

import Foundation
//Data binding between view and view model.
class Observable<T> {
    typealias Listener = (T) -> Void
    private var listener: Listener?
    
    var value: T {
        didSet {
            listener?(value)
        }
    }

    init(_ value: T) {
        self.value = value
    }

    func bind(listener: Listener?) {
        self.listener = listener
        listener?(value)
    }
}
