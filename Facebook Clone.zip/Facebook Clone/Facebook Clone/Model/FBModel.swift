//
//  DogModel.swift
//  ScrollViewFinal
//
//  Created by Naveen Madhu on 12/08/22.
//

import Foundation

class Story: NSObject {
    let storyImage: String
    let storyName: String
    
    init(storyImage: String, storyName: String) {
        self.storyImage = storyImage
        self.storyName = storyName
    }
}

class Post: NSObject {
    let postImage: String
    let postName: String
    
    init(postImage: String, postName: String) {
        self.postImage = postImage
        self.postName = postName
    }
}

class DropDown: NSObject {
    let menuName: String
    
    init(menuName: String) {
        self.menuName = menuName
    }
}


































class SearchModel: NSObject {
    let searchName: String
    let searchImage: String

    init(searchName: String, searchImage: String) {
        self.searchName = searchName
        self.searchImage = searchImage
    }
}
