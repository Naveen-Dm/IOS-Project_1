//
//  SearchTableViewCell.swift
//  Constraints2
//
//  Created by Naveen Madhu on 05/09/22.
//

import UIKit

class SearchTableViewCell: UITableViewCell {
    
    var profileView: UIView = {
        let profileView = UIView()
        profileView.translatesAutoresizingMaskIntoConstraints = false
        profileView.backgroundColor = .white
        return profileView
    }()
    
    var profileImageView: UIImageView = {
        let profileImageView = UIImageView()
        profileImageView.backgroundColor = .systemGray5
        profileImageView.layer.cornerRadius = 30.0
        profileImageView.contentMode = .scaleToFill;
        profileImageView.layer.borderWidth = 3
        profileImageView.layer.borderColor = UIColor.systemBlue.cgColor
        profileImageView.clipsToBounds = true
        profileImageView.translatesAutoresizingMaskIntoConstraints = false
        return profileImageView
    }()
    
    let searchCellLabel: UILabel = {
        let searchCellLabel = UILabel()
        searchCellLabel.translatesAutoresizingMaskIntoConstraints = false
        searchCellLabel.backgroundColor = .white
        searchCellLabel.textColor = .black
        searchCellLabel.font = UIFont(name: "HelveticaNeue", size: 20)
        return searchCellLabel
    }()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.addSubview(searchCellLabel)
        self.addSubview(profileView)
        profileView.addSubview(profileImageView)
        addConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func addConstraints() {
        var constraints = [NSLayoutConstraint]()
        
        constraints.append(profileView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 5.0))
        constraints.append(profileView.topAnchor.constraint(equalTo: self.topAnchor, constant: 5.0))
        constraints.append(profileView.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -5.0))

        constraints.append(profileView.widthAnchor.constraint(equalToConstant: 70))
//        constraints.append(profileView.heightAnchor.constraint(equalToConstant: 80))
        
        constraints.append(profileImageView.leadingAnchor.constraint(equalTo: profileView.leadingAnchor, constant: 5.0))
        constraints.append(profileImageView.topAnchor.constraint(equalTo: profileView.topAnchor, constant: 5.0))
        constraints.append(profileImageView.trailingAnchor.constraint(equalTo: profileView.trailingAnchor, constant: -5.0))
        constraints.append(profileImageView.bottomAnchor.constraint(equalTo: profileView.bottomAnchor, constant: -5.0))
        constraints.append(profileImageView.widthAnchor.constraint(equalToConstant: 50))
        constraints.append(profileImageView.heightAnchor.constraint(equalToConstant: 50))
        
        constraints.append(searchCellLabel.leadingAnchor.constraint(equalTo: profileView.trailingAnchor, constant: 5.0))
        constraints.append(searchCellLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -5.0))
        constraints.append(searchCellLabel.topAnchor.constraint(equalTo: self.topAnchor, constant: 5.0))
        constraints.append(searchCellLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor))
        
        NSLayoutConstraint.activate(constraints)
    }
}


