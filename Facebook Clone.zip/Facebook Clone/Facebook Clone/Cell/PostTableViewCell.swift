//
//  TableViewCell.swift
//  Constraints2
//
//  Created by Naveen Madhu on 26/08/22.
//

import UIKit

class PostTableViewCell: UITableViewCell {
    
    var isClicked = false
    
    // UI Elements
    var cellView: UIView = {
        let cellView = UIView()
        cellView.translatesAutoresizingMaskIntoConstraints = false
        cellView.layer.cornerRadius = 12.0
        return cellView
    }()
    
    var profileView: UIView = {
        let profileView = UIView()
        profileView.translatesAutoresizingMaskIntoConstraints = false
        return profileView
    }()
    
    var profileImageView: UIImageView = {
        let profileImageView = UIImageView()
        profileImageView.backgroundColor = .systemGray5
        profileImageView.layer.cornerRadius = 25.0
        profileImageView.contentMode = .scaleToFill;
        profileImageView.layer.borderWidth = 3
        profileImageView.layer.borderColor = UIColor.systemBlue.cgColor
        profileImageView.clipsToBounds = true
        profileImageView.translatesAutoresizingMaskIntoConstraints = false
        return profileImageView
    }()
    
    let nameLabel: UILabel = {
        let nameLabel = UILabel()
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.backgroundColor = .white
        nameLabel.textColor = .black
        nameLabel.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        return nameLabel
    }()
    
    let subLabel: UILabel = {
        let subLabel = UILabel()
        subLabel.translatesAutoresizingMaskIntoConstraints = false
        subLabel.text = "Suggested for you."
        subLabel.textColor = .gray
        subLabel.font = UIFont(name: "HelveticaNeue", size: 13)
        return subLabel
    }()
    
    var profileStackView: UIStackView = {
        let profileStackView = UIStackView()
        profileStackView.axis = .horizontal
        profileStackView.distribution = .fillEqually
        profileStackView.translatesAutoresizingMaskIntoConstraints = false
        return profileStackView
    }()
    
    var multiplyButton: UIButton = {
        let multiplyButton = UIButton()
        multiplyButton.setImage(UIImage(systemName: "multiply"), for: .normal)
        multiplyButton.translatesAutoresizingMaskIntoConstraints = false
        return multiplyButton
    }()

    var ellipsisButton: UIButton = {
        let ellipsisButton = UIButton()
        ellipsisButton.setImage(UIImage(systemName: "ellipsis"), for: .normal)
        ellipsisButton.translatesAutoresizingMaskIntoConstraints = false
        return ellipsisButton
    }()
    
    var postView: UIView = {
        let postView = UIView()
        postView.translatesAutoresizingMaskIntoConstraints = false
        postView.backgroundColor = .gray
        return postView
    }()

    var postImageView: UIImageView = {
        let postImageView = UIImageView()
        postImageView.backgroundColor = .yellow
        postImageView.contentMode = .scaleAspectFill
        postImageView.translatesAutoresizingMaskIntoConstraints = false
        return postImageView
    }()

    var stackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.backgroundColor = .red
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.backgroundColor = .white
        return stackView
    }()
    
    var likeButton: UIButton = {
        let likeButton = UIButton()
        likeButton.setImage(UIImage(systemName: "hand.thumbsup"), for: .normal)
        likeButton.setTitle("Like", for: .normal)
        likeButton.isUserInteractionEnabled = true
        likeButton.setTitleColor(UIColor.systemGray2, for: .normal)
        likeButton.translatesAutoresizingMaskIntoConstraints = false
        return likeButton
    }()

    var commentButton: UIButton = {
        let commentButton = UIButton()
        commentButton.setImage(UIImage(systemName: "bubble.left"), for: .normal)
        commentButton.setTitle("Comment", for: .normal)
        commentButton.setTitleColor(UIColor.systemGray2, for: .normal)
        commentButton.translatesAutoresizingMaskIntoConstraints = false
        return commentButton
    }()

    var shareButton: UIButton = {
        let shareButton = UIButton()
        shareButton.setImage(UIImage(systemName: "paperplane"), for: .normal)
        shareButton.setTitle("Share", for: .normal)
        shareButton.setTitleColor(UIColor.systemGray2, for: .normal)
        shareButton.translatesAutoresizingMaskIntoConstraints = false
        return shareButton
    }()
    
    private let commentTextField: UITextField = {
        let commentTextField = UITextField()
        commentTextField.translatesAutoresizingMaskIntoConstraints = false
        commentTextField.placeholder = "Write your comment..."
        commentTextField.isHidden = true
        return commentTextField
    }()
    
    private let sendButton: UIButton = {
        let sendButton = UIButton()
        sendButton.setImage(UIImage(systemName: "paperplane.fill"), for: .normal)
        sendButton.translatesAutoresizingMaskIntoConstraints = false
        return sendButton
    }()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        self.addSubview(cellView)
        cellView.addSubview(profileView)
        profileView.addSubview(profileImageView)
        
        cellView.addSubview(nameLabel)
        cellView.addSubview(subLabel)
        
        cellView.addSubview(profileStackView)
        profileStackView.addArrangedSubview(ellipsisButton)
        profileStackView.addArrangedSubview(multiplyButton)
       
        cellView.addSubview(postView)
        postView.addSubview(postImageView)
        
        contentView.addSubview(stackView)
        stackView.addArrangedSubview(likeButton)
        stackView.addArrangedSubview(commentButton)
        stackView.addArrangedSubview(shareButton)
        
        contentView.addSubview(commentTextField)
        commentTextField.rightView = sendButton
        commentTextField.rightViewMode = .always
        commentTextField.delegate = self
        
        buttonActions()
        addConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // Performs button's action in the cell
    private func buttonActions() {
        likeButton.addTarget(self, action: #selector(likeButtonTapped(_:)), for: .touchUpInside)
        commentButton.addTarget(self, action: #selector(commentButtonTapped(_:)), for: .touchUpInside)
        sendButton.addTarget(self, action: #selector(sendButtonPressed(_:)), for: .touchUpInside)
    }
    
    @objc func likeButtonTapped(_ sender: UIButton) {
        if isClicked {
            isClicked = false
            likeButton.setImage(UIImage(systemName: "hand.thumbsup.fill"), for: .normal)
        } else {
            isClicked = true
            likeButton.setImage(UIImage(systemName: "hand.thumbsup"), for: .normal)
        }
    }
    
    @objc func commentButtonTapped(_ sender: UIButton) {
        if isClicked {
            isClicked = false
            commentTextField.isHidden = false
        } else {
            isClicked = true
        }
    }
    
    @objc func sendButtonPressed(_ sender: UIButton) {
        if isClicked {
            isClicked = false
            commentTextField.isHidden = true
        } else {
            isClicked = true
        }
    }
    
    // Adding constraints to UI Elements
    private func addConstraints() {
        var constraints = [NSLayoutConstraint]()
        
        constraints.append(cellView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 5.0))
        constraints.append(cellView.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -5.0))
        constraints.append(cellView.topAnchor.constraint(equalTo: self.topAnchor, constant: 5.0))
        constraints.append(cellView.bottomAnchor.constraint(equalTo: self.bottomAnchor))
        
        constraints.append(profileView.leadingAnchor.constraint(equalTo: cellView.leadingAnchor, constant: 5.0))
        constraints.append(profileView.topAnchor.constraint(equalTo: cellView.topAnchor, constant: 5.0))
        constraints.append(profileView.widthAnchor.constraint(equalToConstant: 70))
        constraints.append(profileView.heightAnchor.constraint(equalToConstant: 70))
        
        constraints.append(profileImageView.leadingAnchor.constraint(equalTo: profileView.leadingAnchor, constant: 5.0))
        constraints.append(profileImageView.topAnchor.constraint(equalTo: profileView.topAnchor, constant: 5.0))
        constraints.append(profileImageView.widthAnchor.constraint(equalToConstant: 50))
        constraints.append(profileImageView.heightAnchor.constraint(equalToConstant: 50))

        constraints.append(nameLabel.leadingAnchor.constraint(equalTo: profileView.trailingAnchor, constant: 10.0))
        constraints.append(nameLabel.topAnchor.constraint(equalTo: cellView.topAnchor, constant: 10.0))
        constraints.append(nameLabel.widthAnchor.constraint(equalToConstant: 200))
        constraints.append(nameLabel.heightAnchor.constraint(equalToConstant: 30))
        
        constraints.append(subLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor))
        constraints.append(subLabel.trailingAnchor.constraint(equalTo: nameLabel.trailingAnchor))
        constraints.append(subLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor))
        constraints.append(subLabel.heightAnchor.constraint(equalToConstant: 20))
        
        constraints.append(profileStackView.leadingAnchor.constraint(equalTo: nameLabel.trailingAnchor, constant: 10.0))
        constraints.append(profileStackView.topAnchor.constraint(equalTo: cellView.topAnchor, constant: 10.0))
        constraints.append(profileStackView.widthAnchor.constraint(equalToConstant: 100))
        constraints.append(profileStackView.heightAnchor.constraint(equalToConstant: 50))

        constraints.append(postView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 15.0))
        constraints.append(postView.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -15.0))
        constraints.append(postView.topAnchor.constraint(equalTo: profileView.bottomAnchor, constant: 8.0))
//        constraints.append(postView.heightAnchor.constraint(equalToConstant: 275))

        constraints.append(postImageView.leadingAnchor.constraint(equalTo: postView.leadingAnchor))
        constraints.append(postImageView.trailingAnchor.constraint(equalTo: postView.trailingAnchor))
        constraints.append(postImageView.topAnchor.constraint(equalTo: postView.topAnchor))
        constraints.append(postImageView.heightAnchor.constraint(equalToConstant: 275))

        constraints.append(stackView.leadingAnchor.constraint(equalTo: self.leadingAnchor))
        constraints.append(stackView.trailingAnchor.constraint(equalTo: self.trailingAnchor))
        constraints.append(stackView.topAnchor.constraint(equalTo: postImageView.bottomAnchor, constant: 1.0))
        constraints.append(stackView.heightAnchor.constraint(equalToConstant: 50))
        
        constraints.append(commentTextField.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 5.0))
        constraints.append(commentTextField.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -5.0))
        constraints.append(commentTextField.topAnchor.constraint(equalTo: stackView.bottomAnchor))
        constraints.append(commentTextField.heightAnchor.constraint(equalToConstant: 25))
            
        NSLayoutConstraint.activate(constraints)
    }
}

extension PostTableViewCell {
//     Assigning values to the labels in the cell
    func nameInitialization(item: Post){
        nameLabel.text = item.postName
    }
    
//     Loading image to the imageView in the cell
    func imageInitialization(post: Post) {
        postImageView.image = UIImage(named: post.postImage)
        profileImageView.image = UIImage(named: post.postImage)
    }
}

extension PostTableViewCell: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        commentTextField.resignFirstResponder()
        return true
    }
}
