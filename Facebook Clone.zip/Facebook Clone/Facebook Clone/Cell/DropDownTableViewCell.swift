//
//  CollectionViewCell.swift
//  Constraints2
//
//  Created by Naveen Madhu on 26/08/22.
//

import UIKit

class DropDownTableViewCell: UITableViewCell {
    let dropDownMenu: UILabel = {
        let dropDownMenu = UILabel()
        dropDownMenu.translatesAutoresizingMaskIntoConstraints = false
        dropDownMenu.backgroundColor = .white
        dropDownMenu.textColor = .black
        dropDownMenu.font = UIFont(name: "HelveticaNeue-Bold", size: 10)
        return dropDownMenu
    }()
    
     let postPlusButton: UIButton = {
        let postPlusButton = UIButton()
        postPlusButton.setImage(UIImage(systemName: "plus"), for: .normal)
        postPlusButton.translatesAutoresizingMaskIntoConstraints = false
        return postPlusButton
    }()

     let storyButton: UIButton = {
        let storyButton = UIButton()
        storyButton.setImage(UIImage(systemName: "gobackward"), for: .normal)
        storyButton.translatesAutoresizingMaskIntoConstraints = false
        return storyButton
    }()
    
     let savedButton: UIButton = {
        let savedButton = UIButton()
        savedButton.setImage(UIImage(systemName: "bookmark"), for: .normal)
        savedButton.translatesAutoresizingMaskIntoConstraints = false
        return savedButton
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.addSubview(dropDownMenu)
//        self.addSubview(postPlusButton)
//        self.addSubview(storyButton)
//        self.addSubview(savedButton)
        addConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func addConstraints() {
        var constraints = [NSLayoutConstraint]()
        
        constraints.append(dropDownMenu.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 5.0))
        constraints.append(dropDownMenu.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -30.0))
        constraints.append(dropDownMenu.topAnchor.constraint(equalTo: self.topAnchor, constant: 5.0))
        constraints.append(dropDownMenu.bottomAnchor.constraint(equalTo: self.bottomAnchor))
        
//        constraints.append(postPlusButton.trailingAnchor.constraint(equalTo: self.trailingAnchor))
//        constraints.append(postPlusButton.topAnchor.constraint(equalTo: self.topAnchor))
//        constraints.append(postPlusButton.bottomAnchor.constraint(equalTo: self.bottomAnchor))
//        constraints.append(postPlusButton.widthAnchor.constraint(equalToConstant: 30.0))
//
//        constraints.append(storyButton.trailingAnchor.constraint(equalTo: self.trailingAnchor))
//        constraints.append(storyButton.topAnchor.constraint(equalTo: self.topAnchor))
//        constraints.append(storyButton.bottomAnchor.constraint(equalTo: self.bottomAnchor))
//        constraints.append(storyButton.widthAnchor.constraint(equalToConstant: 30.0))
//
//        constraints.append(savedButton.trailingAnchor.constraint(equalTo: self.trailingAnchor))
//        constraints.append(storyButton.topAnchor.constraint(equalTo: self.topAnchor))
//        constraints.append(storyButton.bottomAnchor.constraint(equalTo: self.bottomAnchor))
//        constraints.append(storyButton.widthAnchor.constraint(equalToConstant: 30.0))
        
        NSLayoutConstraint.activate(constraints)
    }
}
