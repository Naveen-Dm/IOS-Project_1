//
//  SearchViewController.swift
//  Constraints2
//
//  Created by Naveen Madhu on 08/09/22.
//

import UIKit

class ShareViewController: UIViewController {
    
    let shareViewModel: ShareViewModel = ShareViewModel()
    
    private let shareTableView: UITableView = {
        let shareTableView = UITableView()
        shareTableView.register(ShareTableViewCell.classForCoder(), forCellReuseIdentifier: "shareCell")
        shareTableView.translatesAutoresizingMaskIntoConstraints = false
        shareTableView.backgroundColor = .clear
        return shareTableView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if touch?.view != shareTableView {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    private func initialSetup() {
        view.backgroundColor = .clear
        view.addSubview(shareTableView)
        shareTable()
    }
    
    private func shareTable() {
        shareTableView.delegate = self
        shareTableView.dataSource = self
        shareTableView.estimatedRowHeight = UITableView.automaticDimension

        NSLayoutConstraint.activate([
            shareTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            shareTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            shareTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            shareTableView.heightAnchor.constraint(equalToConstant: 700.0)

        ])
    }
}

extension ShareViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shareViewModel.shareList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "shareCell", for: indexPath) as! ShareTableViewCell
        cell.selectionStyle = .none
        
        if (indexPath.row == 0) {
            
            cell.addSubview(cell.profileImageView)
            cell.addSubview(cell.nameLabel)
            cell.addSubview(cell.commentTextView)
            cell.addSubview(cell.destinationDropDownTableView)
            cell.addSubview(cell.audienceTableView)
            cell.commentTextView.delegate = self
            textViewDidChange(cell.commentTextView)
            cell.contentView.addSubview(cell.shareButton)
            cell.contentView.addSubview(cell.postAudienceButton)
            cell.contentView.addSubview(cell.destinationButton)
            cell.cellView.backgroundColor = .clear
            
            cell.profileImageView.topAnchor.constraint(equalTo: cell.cellView.topAnchor, constant: 5.0).isActive = true
            cell.profileImageView.leadingAnchor.constraint(equalTo: cell.cellView.leadingAnchor, constant: 5.0).isActive = true
            cell.profileImageView.widthAnchor.constraint(equalToConstant: 50.0).isActive = true
            cell.profileImageView.heightAnchor.constraint(equalToConstant: 50.0).isActive = true
            
            cell.nameLabel.topAnchor.constraint(equalTo: cell.profileImageView.topAnchor).isActive = true
            cell.nameLabel.leadingAnchor.constraint(equalTo: cell.profileImageView.trailingAnchor, constant: 5.0).isActive = true
            cell.nameLabel.widthAnchor.constraint(equalToConstant: 200.0).isActive = true
            cell.nameLabel.heightAnchor.constraint(equalToConstant: 20.0).isActive = true
            
            cell.destinationButton.topAnchor.constraint(equalTo: cell.nameLabel.bottomAnchor, constant: 1.0).isActive = true
            cell.destinationButton.leadingAnchor.constraint(equalTo: cell.nameLabel.leadingAnchor, constant: 1.0).isActive = true
            cell.destinationButton.widthAnchor.constraint(equalToConstant: 170.0).isActive = true
            cell.destinationButton.heightAnchor.constraint(equalToConstant: 25.0).isActive = true
            
            cell.postAudienceButton.topAnchor.constraint(equalTo: cell.nameLabel.bottomAnchor, constant: 1.0).isActive = true
            cell.postAudienceButton.leadingAnchor.constraint(equalTo: cell.destinationButton.trailingAnchor, constant: 5.0).isActive = true
            cell.postAudienceButton.widthAnchor.constraint(equalToConstant: 110.0).isActive = true
            cell.postAudienceButton.heightAnchor.constraint(equalToConstant: 25.0).isActive = true
            
            cell.commentTextView.topAnchor.constraint(equalTo: cell.profileImageView.bottomAnchor, constant: 5.0).isActive = true
            cell.commentTextView.leadingAnchor.constraint(equalTo: cell.cellView.leadingAnchor, constant: 5.0).isActive = true
            cell.commentTextView.trailingAnchor.constraint(equalTo: cell.cellView.trailingAnchor, constant: -5.0).isActive = true
            cell.commentTextView.heightAnchor.constraint(equalToConstant: 90.0).isActive = true
            
            cell.shareButton.trailingAnchor.constraint(equalTo: cell.cellView.trailingAnchor, constant: -5.0).isActive = true
            cell.shareButton.bottomAnchor.constraint(equalTo: cell.cellView.bottomAnchor, constant: -5.0).isActive = true
            cell.shareButton.heightAnchor.constraint(equalToConstant: 40.0).isActive = true
            cell.shareButton.widthAnchor.constraint(equalToConstant: 100.0).isActive = true

            cell.destinationDropDownTableView.topAnchor.constraint(equalTo: cell.destinationButton.bottomAnchor, constant: 2.0).isActive = true
            cell.destinationDropDownTableView.leadingAnchor.constraint(equalTo: cell.destinationButton.leadingAnchor).isActive = true
            cell.destinationDropDownTableView.trailingAnchor.constraint(equalTo: cell.destinationButton.trailingAnchor).isActive = true
            cell.destinationDropDownTableView.heightAnchor.constraint(equalToConstant: 120.0).isActive = true
            
            cell.audienceTableView.topAnchor.constraint(equalTo: cell.postAudienceButton.bottomAnchor, constant: 2.0).isActive = true
            cell.audienceTableView.leadingAnchor.constraint(equalTo: cell.postAudienceButton.leadingAnchor).isActive = true
            cell.audienceTableView.trailingAnchor.constraint(equalTo: cell.postAudienceButton.trailingAnchor).isActive = true
            cell.audienceTableView.heightAnchor.constraint(equalToConstant: 120.0).isActive = true
        } else {
            cell.addSubview(cell.shareMenuLabel)
            cell.cellView.backgroundColor = .clear
            
            cell.shareMenuLabel.leadingAnchor.constraint(equalTo: cell.cellView.leadingAnchor, constant: 5.0).isActive = true
            cell.shareMenuLabel.trailingAnchor.constraint(equalTo: cell.cellView.trailingAnchor, constant: -5.0).isActive = true
            cell.shareMenuLabel.topAnchor.constraint(equalTo: cell.cellView.topAnchor, constant: 5.0).isActive = true
            cell.shareMenuLabel.bottomAnchor.constraint(equalTo: cell.cellView.bottomAnchor, constant: -5.0).isActive = true
            
            cell.shareMenuLabel.text = shareViewModel.shareList[indexPath.row].shareMenuName
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (indexPath.row == 0) {
            return 200
        } else {
            return 80
        }
        
    }
}

extension ShareViewController: UITextViewDelegate {
    func textViewDidChange(_ textView: UITextView) {
        print(textView.text!)
        let size = CGSize(width: view.frame.width, height: .infinity)
        let estimatedSize = textView.sizeThatFits(size)
        
        textView.constraints.forEach{ (constraint) in
            if constraint.firstAttribute == .height {
                constraint.constant = estimatedSize.height
            }
        }
    }
}
