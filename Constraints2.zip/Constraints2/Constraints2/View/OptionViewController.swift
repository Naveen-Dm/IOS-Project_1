//
//  OptionViewController.swift
//  Constraints2
//
//  Created by Naveen Madhu on 16/09/22.
//

import UIKit

class OptionViewController: UIViewController {
    
    var optionViewModel: OptionViewModel = OptionViewModel()
    
    let optionTableView: UITableView = {
        let optionTableView = UITableView()
        optionTableView.register(OptionTableViewCell.classForCoder(), forCellReuseIdentifier: "optionCell")
        optionTableView.translatesAutoresizingMaskIntoConstraints = false
        optionTableView.backgroundColor = .red
        return optionTableView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        initialSetup()
    }
    
    private func initialSetup() {
        view.backgroundColor = .clear
        view.addSubview(optionTableView)
        optionTable()
    }
    
    private func optionTable() {
        optionTableView.delegate = self
        optionTableView.dataSource = self
        optionTableView.estimatedRowHeight = UITableView.automaticDimension

        NSLayoutConstraint.activate([
            optionTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            optionTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            optionTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            optionTableView.heightAnchor.constraint(equalToConstant: 700.0)

        ])
    }
}

extension OptionViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return optionViewModel.optionList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "optionCell", for: indexPath) as! OptionTableViewCell
        cell.optionLabel.text = optionViewModel.optionList[indexPath.row].optionMenuName
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
}
