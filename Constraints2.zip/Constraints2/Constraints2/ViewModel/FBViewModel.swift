//
//  DogViewModel.swift
//  ScrollViewFinal
//
//  Created by Naveen Madhu on 12/08/22.
//

import Foundation
import UIKit

class CollectionViewModel: NSObject {
    
    // Properties
    var storyList = Array<Story>()
    
    override init() {
        let addStory = Story(storyImage: "story", storyName: "Create story")
        let story1 = Story(storyImage: "boy6", storyName: "Aryan")
        let story2 = Story(storyImage: "girl9", storyName: "Anushka")
        let story3 = Story(storyImage: "boy7", storyName: "Gaurang")
        let story4 = Story(storyImage: "boy8", storyName: "Hritik")
        let story5 = Story(storyImage: "girl5", storyName: "Farida")
        let story6 = Story(storyImage: "girl3", storyName: "Kareena")
        let story7 = Story(storyImage: "boy9", storyName: "Kabir")
        let story8 = Story(storyImage: "girl7", storyName: "Shaniya")
        let story9 = Story(storyImage: "girl3", storyName: "Sonia")
        let story10 = Story(storyImage: "boy10", storyName: "Lucky")
        
    

        
        storyList.append(addStory)
        storyList.append(story1)
        storyList.append(story2)
        storyList.append(story3)
        storyList.append(story4)
        storyList.append(story5)
        storyList.append(story6)
        storyList.append(story7)
        storyList.append(story8)
        storyList.append(story9)
        storyList.append(story10)
    }
}

class PostViewModel: NSObject {
    
    // Properties
    var postList = Array<Post>()
    
    override init() {
        let color = Post(postImage: "gray", postName: "gray color")
        let post1 = Post(postImage: "boy2", postName: "Aarush")
        let post2 = Post(postImage: "boy5", postName: "Avyaan")
        let post3 = Post(postImage: "girl6", postName: "Meera")
        let post4 = Post(postImage: "boy3", postName: "Advik")
        let post5 = Post(postImage: "girl8", postName: "Saanvi")
        let post6 = Post(postImage: "girl2", postName: "Sarika")
        let post7 = Post(postImage: "boy4", postName: "Agastya")
        let post8 = Post(postImage: "girl4", postName: "Shyla")
        let post9 = Post(postImage: "boy1", postName: "Anirudh")  
        let post10 = Post(postImage: "girl10", postName: "Aashvi")
        

        
        postList.append(color)
        postList.append(post1)
        postList.append(post2)
        postList.append(post3)
        postList.append(post4)
        postList.append(post5)
        postList.append(post6)
        postList.append(post7)
        postList.append(post8)
        postList.append(post9)
        postList.append(post10)
    }
}

class DropDownViewModel: NSObject {
    var menuList = Array<DropDown>()
    
    override init() {
        let menu1 = DropDown(menuName: "Post")
        let menu2 = DropDown(menuName: "Story")
        let menu3 = DropDown(menuName: "Saved")
        
        menuList.append(menu1)
        menuList.append(menu2)
        menuList.append(menu3)
    }
}

class SearchViewModel: NSObject {
    
        var searchList = Array<SearchModel>()
    var searched = [SearchModel]()

        override init() {
            let search1 = SearchModel(searchName: "Aarush", searchImage: "boy1")
            let search2 = SearchModel(searchName: "Avyaan", searchImage: "boy2")
            let search3 = SearchModel(searchName: "Meera", searchImage: "girl1")
            let search4 = SearchModel(searchName: "Advik", searchImage: "boy3")
            let search5 = SearchModel(searchName: "Saanvi", searchImage: "girl2")
            let search6 = SearchModel(searchName: "Sarika", searchImage: "girl3")
            let search7 = SearchModel(searchName: "Agastya", searchImage: "boy4")
            let search8 = SearchModel(searchName: "Shyla", searchImage: "girl4")
            let search9 = SearchModel(searchName: "Anirudh", searchImage: "boy5")
            let search10 = SearchModel(searchName: "Aashvi", searchImage: "girl5")


            searchList.append(search1)
            searchList.append(search2)
            searchList.append(search3)
            searchList.append(search4)
            searchList.append(search5)
            searchList.append(search6)
            searchList.append(search7)
            searchList.append(search8)
            searchList.append(search9)
            searchList.append(search10)
        }
    
    let nameData = ["Aarush", "Avyaan", "Meera", "Advik", "Saanvi"]
    var searchedName = [String]()

    let logoImage: [UIImage] = [
        UIImage(named: "boy3")!,
        UIImage(named: "boy2")!,
        UIImage(named: "boy1")!,
        UIImage(named: "boy4")!,
        UIImage(named: "boy5")!
    ]
    var searchedImage = [UIImage]()
}

class ShareViewModel: NSObject {
    var shareList = Array<Share>()
    
    override init() {
        let shareMenu1 = Share(shareMenuName: "Share to your story")
        let shareMenu2 = Share(shareMenuName: "Share to your Page's story")
        let shareMenu3 = Share(shareMenuName: "Send in Whatsapp")
        let shareMenu4 = Share(shareMenuName: "Send in Messenger")
        let shareMenu5 = Share(shareMenuName: "Share to a group")
        let shareMenu6 = Share(shareMenuName: "Share to a Page")
        let shareMenu7 = Share(shareMenuName: "More options...")

        shareList.append(shareMenu1)
        shareList.append(shareMenu2)
        shareList.append(shareMenu3)
        shareList.append(shareMenu4)
        shareList.append(shareMenu5)
        shareList.append(shareMenu6)
        shareList.append(shareMenu7)

    }
}

class DestinationDropDownViewModel: NSObject {
    var destinationMenuList = Array<DestinationDropDown>()
    
    override init() {
        let menu1 = DestinationDropDown(destinationMenuName: "Share to News Feed")
        let menu2 = DestinationDropDown(destinationMenuName: "On a friend's timeline")
        let menu3 = DestinationDropDown(destinationMenuName: "In a group")
        let menu4 = DestinationDropDown(destinationMenuName: "On your Page")

        
        destinationMenuList.append(menu1)
        destinationMenuList.append(menu2)
        destinationMenuList.append(menu3)
        destinationMenuList.append(menu4)
    }
}

class PostAudienceDropDownViewModel: NSObject {
    var audienceMenuList = Array<PostAudienceDropDown>()
    
    override init() {
        let menu1 = PostAudienceDropDown(AudienceMenuName: "Public")
        let menu2 = PostAudienceDropDown(AudienceMenuName: "Friends")
        let menu3 = PostAudienceDropDown(AudienceMenuName: "Friends except...")
        let menu4 = PostAudienceDropDown(AudienceMenuName: "Only me")

        
        audienceMenuList.append(menu1)
        audienceMenuList.append(menu2)
        audienceMenuList.append(menu3)
        audienceMenuList.append(menu4)
    }
}

class OptionViewModel: NSObject {
    var optionList = Array<Option>()
    
    override init() {
        let optionMenu1 = Option(optionMenuName: "Save post")
        let optionMenu2 = Option(optionMenuName: "Hide post")
        let optionMenu3 = Option(optionMenuName: "Report post")
        let optionMenu4 = Option(optionMenuName: "Turn on notification for this post")
        let optionMenu5 = Option(optionMenuName: "Copy link")
        let optionMenu6 = Option(optionMenuName: "Add to favorites")
        let optionMenu7 = Option(optionMenuName: "Snooze for 30 days")
        let optionMenu8 = Option(optionMenuName: "Unfollow")
        let optionMenu9 = Option(optionMenuName: "Manage your Feed")

        optionList.append(optionMenu1)
        optionList.append(optionMenu2)
        optionList.append(optionMenu3)
        optionList.append(optionMenu4)
        optionList.append(optionMenu5)
        optionList.append(optionMenu6)
        optionList.append(optionMenu7)
        optionList.append(optionMenu8)
        optionList.append(optionMenu9)


    }
}




//    let imageData = ["boy2","boy5","girl6","boy3","girl8","girl2","boy4","girl4","boy1","girl10","boy6","girl9","boy7","boy8","girl5","girl3","boy9","girl7","girl3","boy10"]
//    var searchedImage = [String]()


//let nameData = ["Aarush", "Avyaan", "Meera", "Advik", "Saanvi", "Sarika", "Agastya", "Shyla", "Anirudh", "Aashvi", "Aryan", "Anushka", "Gaurang", "Hritik", "Farida", "Kareena", "Kabir", "Shaniya", "Sonia", "Lucky"]






























