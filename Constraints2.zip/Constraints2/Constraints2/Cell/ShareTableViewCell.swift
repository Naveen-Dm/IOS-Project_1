//
//  ShareTableViewCell.swift
//  Constraints2
//
//  Created by Naveen Madhu on 08/09/22.
//

import UIKit

class ShareTableViewCell: UITableViewCell {
    
    
    var destinationVM: DestinationDropDownViewModel = DestinationDropDownViewModel()
    var audienceVM: PostAudienceDropDownViewModel = PostAudienceDropDownViewModel()
    
    var isClicked = true
    
    var cellView: UIView = {
        let cellView = UIView()
        cellView.translatesAutoresizingMaskIntoConstraints = false
        cellView.layer.cornerRadius = 12.0
        return cellView
    }()
    
    var profileView: UIView = {
        let profileView = UIView()
        profileView.translatesAutoresizingMaskIntoConstraints = false
        return profileView
    }()
    
    var profileImageView: UIImageView = {
        let profileImageView = UIImageView()
        profileImageView.image = UIImage(named: "icon image")
        profileImageView.layer.cornerRadius = 25.0
        profileImageView.contentMode = .scaleToFill;
        profileImageView.clipsToBounds = true
        profileImageView.translatesAutoresizingMaskIntoConstraints = false
        return profileImageView
    }()
    
    let nameLabel: UILabel = {
        let nameLabel = UILabel()
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.text = "Naveen"
        nameLabel.font = UIFont(name: "HelveticaNeue-Bold", size: 15)
        return nameLabel
    }()
    
    let destinationButton: UIButton = {
        let destinationButton = UIButton()
        destinationButton.translatesAutoresizingMaskIntoConstraints = false
        destinationButton.setImage(UIImage(systemName: "chevron.down"), for: .normal)
        destinationButton.setTitle("News Feed                         ", for: .normal)
        destinationButton.titleLabel?.font = .systemFont(ofSize: 12.0)
        destinationButton.contentHorizontalAlignment = .left
        destinationButton.layer.cornerRadius = 5.0
        destinationButton.contentMode = .scaleToFill;
        destinationButton.layer.borderWidth = 1
        destinationButton.layer.borderColor = UIColor.gray.cgColor
        destinationButton.setTitleColor(UIColor.black, for: .normal)
        destinationButton.semanticContentAttribute = .forceRightToLeft
        return destinationButton
    }()
    
    let postAudienceButton: UIButton = {
        let postAudienceButton = UIButton()
        postAudienceButton.translatesAutoresizingMaskIntoConstraints = false
        postAudienceButton.setImage(UIImage(systemName: "chevron.down"), for: .normal)
        postAudienceButton.setTitle("Public                  ", for: .normal)
        postAudienceButton.titleLabel?.font = .systemFont(ofSize: 11.0)
        postAudienceButton.contentHorizontalAlignment = .left
        postAudienceButton.layer.cornerRadius = 5.0
        postAudienceButton.contentMode = .scaleToFill;
        postAudienceButton.layer.borderWidth = 1
        postAudienceButton.layer.borderColor = UIColor.gray.cgColor
        postAudienceButton.setTitleColor(UIColor.black, for: .normal)
        postAudienceButton.semanticContentAttribute = .forceRightToLeft
        return postAudienceButton
    }()
    
    let commentTextView: UITextView = {
        let commentTextView = UITextView()
        commentTextView.translatesAutoresizingMaskIntoConstraints = false
        commentTextView.frame = CGRect(x: 0, y: 0, width: 200, height: 100)
        commentTextView.backgroundColor = .white
        commentTextView.font = UIFont.preferredFont(forTextStyle: .headline)
        commentTextView.text = "Say something about this... "
        commentTextView.backgroundColor = .red
        commentTextView.isScrollEnabled = false
        return commentTextView
    }()
    
    let shareButton: UIButton = {
        let shareButton = UIButton()
        shareButton.translatesAutoresizingMaskIntoConstraints = false
        shareButton.backgroundColor = .systemBlue
        shareButton.setTitle("Share Now", for: .normal)
        shareButton.setTitleColor(UIColor.white, for: .normal)
        shareButton.layer.cornerRadius = 5
        return shareButton
    }()
    
    let shareMenuLabel: UILabel = {
        let shareMenuLabel = UILabel()
        shareMenuLabel.translatesAutoresizingMaskIntoConstraints = false
        shareMenuLabel.font = UIFont(name: "", size: 20)
        return shareMenuLabel
    }()
    
    let destinationDropDownTableView: UITableView = {
        let destinationDropDownTableView = UITableView()
        destinationDropDownTableView.register(DestinationTableViewCell.self, forCellReuseIdentifier: DestinationTableViewCell.identifier1)
        destinationDropDownTableView.translatesAutoresizingMaskIntoConstraints = false
        destinationDropDownTableView.backgroundColor = .blue
        destinationDropDownTableView.isHidden = true
        return destinationDropDownTableView
    }()
    
    let audienceTableView: UITableView = {
        let audienceTableView = UITableView()
        audienceTableView.register(AudienceTableViewCell.self, forCellReuseIdentifier: AudienceTableViewCell.identifier2)
        audienceTableView.translatesAutoresizingMaskIntoConstraints = false
        audienceTableView.backgroundColor = .red
        audienceTableView.isHidden = true
        return audienceTableView
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.addSubview(cellView)
        
        destinationDropDownTableView.delegate = self
        destinationDropDownTableView.dataSource = self
        
        audienceTableView.delegate = self
        audienceTableView.dataSource = self
        
        buttonAction()
        addConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func buttonAction() {
        destinationButton.addTarget(self, action: #selector(destinationButtonPressed(_:)), for: .touchUpInside)
        postAudienceButton.addTarget(self, action: #selector(audienceButtonPressed(_:)), for: .touchUpInside)
        shareButton.addTarget(self, action: #selector(shareButtonTapped(_:)), for: .touchUpInside)
    }
    
    @objc func shareButtonTapped(_ sender: UIButton) {
        if isClicked {
            shareButton.setImage(UIImage(systemName: "checkmark"), for: .normal)
            shareButton.backgroundColor = .white
        }
    }
    
    // To show drop down menu
    @objc func destinationButtonPressed(_ sender: UITapGestureRecognizer) {
        if destinationDropDownTableView.isHidden {
            animate(toggle: true)
        } else {
            animate(toggle: false)
        }
    }
    
    func animate(toggle: Bool) {
        if toggle {
            UIView.animate(withDuration: 0.5) {
                self.destinationDropDownTableView.isHidden = false
            }
        } else {
            UIView.animate(withDuration: 0.5) {
                self.destinationDropDownTableView.isHidden = true
            }
        }
    }
    
    @objc func audienceButtonPressed(_ sender: UITapGestureRecognizer) {
        if audienceTableView.isHidden {
            animate1(toggle: true)
        } else {
            animate1(toggle: false)
        }
    }
    
    func animate1(toggle: Bool) {
        if toggle {
            UIView.animate(withDuration: 0.5) {
                self.audienceTableView.isHidden = false
            }
        } else {
            UIView.animate(withDuration: 0.5) {
                self.audienceTableView.isHidden = true
            }
        }
    }
    
    // Adding constraints to UI Elements
    private func addConstraints() {
        var constraints = [NSLayoutConstraint]()
        
        constraints.append(cellView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 5.0))
        constraints.append(cellView.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -5.0))
        constraints.append(cellView.topAnchor.constraint(equalTo: self.topAnchor, constant: 5.0))
        constraints.append(cellView.bottomAnchor.constraint(equalTo: self.bottomAnchor))
      
        NSLayoutConstraint.activate(constraints)
    }
    
}


extension ShareTableViewCell: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == destinationDropDownTableView {
            return destinationVM.destinationMenuList.count
        } else {
            return audienceVM.audienceMenuList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == destinationDropDownTableView {
            let menu = destinationVM.destinationMenuList[indexPath.row]
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "DestinationCell", for: indexPath) as! DestinationTableViewCell
            cell.menuLabel.text = menu.destinationMenuName
            return cell
        } else {
            let menu1 = audienceVM.audienceMenuList[indexPath.row]
            let cell1 = tableView.dequeueReusableCell(withIdentifier: "audienceCell", for: indexPath) as! AudienceTableViewCell
            cell1.menuLabel.text = menu1.AudienceMenuName
            return cell1

        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 30
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if tableView == destinationDropDownTableView {
            destinationButton.setTitle("\(destinationVM.destinationMenuList[indexPath.row].destinationMenuName)", for: .normal)
            animate(toggle: false)
        } else {
            postAudienceButton.setTitle("\(audienceVM.audienceMenuList[indexPath.row].AudienceMenuName)", for: .normal)
            animate1(toggle: false)
        }
    }
}
