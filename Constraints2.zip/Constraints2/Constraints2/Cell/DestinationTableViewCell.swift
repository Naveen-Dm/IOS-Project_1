//
//  DestinationTableViewCell.swift
//  Constraints2
//
//  Created by Naveen Madhu on 14/09/22.
//

import UIKit

class DestinationTableViewCell: UITableViewCell {
    
    static let identifier1 = "DestinationCell"
    
    let menuLabel: UILabel = {
        let menuLabel = UILabel()
        menuLabel.translatesAutoresizingMaskIntoConstraints  = false
        menuLabel.font = UIFont(name: "", size: 10)
        return menuLabel
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.addSubview(menuLabel)
        addConstraints()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func addConstraints(){
        var constraints = [NSLayoutConstraint]()
        
        constraints.append(menuLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 5.0))
        constraints.append(menuLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20.0))
        constraints.append(menuLabel.topAnchor.constraint(equalTo: self.topAnchor, constant: 5.0))
        constraints.append(menuLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor))

        //Activate
        NSLayoutConstraint.activate(constraints)
    }
}
