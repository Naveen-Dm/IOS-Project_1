//
//  OptionTableViewCell.swift
//  Constraints2
//
//  Created by Naveen Madhu on 19/09/22.
//

import UIKit

class OptionTableViewCell: UITableViewCell {
    
    let optionLabel: UILabel = {
        let optionLabel = UILabel()
        optionLabel.translatesAutoresizingMaskIntoConstraints  = false
        optionLabel.font = UIFont(name: "HelveticaNeue-Bold", size: 15)
        return optionLabel
    }()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.addSubview(optionLabel)
        addConstraints()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func addConstraints(){
        var constraints = [NSLayoutConstraint]()
        
        constraints.append(optionLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 5.0))
        constraints.append(optionLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20.0))
        constraints.append(optionLabel.topAnchor.constraint(equalTo: self.topAnchor, constant: 5.0))
        constraints.append(optionLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor))

        //Activate
        NSLayoutConstraint.activate(constraints)
    }

}
