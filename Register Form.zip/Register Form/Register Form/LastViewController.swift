//
//  LastViewController.swift
//  Register Form
//
//  Created by Naveen Madhu on 28/06/22.
//

import Foundation
import UIKit

class LastViewController: UIViewController {
    //MARK: IBOutlet
    @IBOutlet weak var logoutButton: UIButton!
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        logoutButtonDesign()
    }
    
    func logoutButtonDesign() {
        // To round the corners
        logoutButton.layer.cornerRadius = 20
        logoutButton.clipsToBounds = true
        // To provide the shadow
        logoutButton.layer.shadowRadius = 10
        logoutButton.layer.shadowOpacity = 1.0
        logoutButton.layer.shadowOffset = CGSize(width: 3, height: 3)
        logoutButton.layer.shadowColor = UIColor.white.cgColor
        logoutButton.layer.masksToBounds = false
    }
    
    // Removes the login credentials when the logout button is pressed
    @IBAction func logoutButtonPressed(_ sender: UIButton) {
        defaults.removeObject(forKey: "keyUserName")
        defaults.removeObject(forKey: "keyPassword")
        defaults.synchronize()
        self.presentingViewController?.presentingViewController?.presentingViewController?.dismiss(animated: true)
    }
}
