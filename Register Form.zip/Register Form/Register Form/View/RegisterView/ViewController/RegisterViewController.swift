//
//  ViewController.swift
//  Login Form TableView
//
//  Created by Naveen Madhu on 09/06/22.
//

import UIKit
import AVFoundation

class RegisterViewController: UIViewController {
    
    // Stored Properties
    var registrationViewModel: RegistrationViewModel = RegistrationViewModel()
    var detailsTextViewCell: DetailsTextViewCell = DetailsTextViewCell()
    let emailValidityType: String.ValidityType = .emailAddress
    let phoneNumberValidityType: String.ValidityType = .phoneNumber
    let passwordValidityType: String.ValidityType = .password
    let datePicker = UIDatePicker()
    var audio: AVAudioPlayer?
    
    // IBOutlets
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var registerButton: UIButton!
    @IBOutlet weak var registerErrorLabel: UILabel!
    @IBOutlet weak var backButton: UIButton!

    // Life Cycles
    override func viewDidLoad() {
        super.viewDidLoad()
        registerCell()
        registerButtonDesign()
    }

    private func registerButtonDesign() {
        // To round the corners
        registerButton.layer.cornerRadius = 20
        registerButton.clipsToBounds = true
        // To provide the shadow
        registerButton.layer.shadowRadius = 10
        registerButton.layer.shadowOpacity = 1.0
        registerButton.layer.shadowOffset = CGSize(width: 3, height: 3)
        registerButton.layer.shadowColor = UIColor.white.cgColor
        registerButton.layer.masksToBounds = false
    }
    
    private func registerCell(){
        tableView.register(UINib(nibName: "DetailsTableCell", bundle: nil), forCellReuseIdentifier: "DetailsTableCell")
        tableView.register(UINib(nibName: "DetailsTextViewCell", bundle: nil), forCellReuseIdentifier: "DetailsTextViewCell")
    }
    
    @IBAction func registerButtonPressed(_ sender: Any) {
        let lastModel = storyboard?.instantiateViewController(withIdentifier: "LastViewController") as! LastViewController
        self.present(lastModel, animated: true)
    }
    
    @IBAction func backButtonPressed(_ sender: Any) {
        self.presentingViewController?.dismiss(animated: true)
    }
}

// TableView Delegates and data source
extension RegisterViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return registrationViewModel.formList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if (indexPath.row == 5) {
            let cell1 = tableView.dequeueReusableCell(withIdentifier: "DetailsTextViewCell", for: indexPath) as! DetailsTextViewCell
            cell1.textViewtitleLabe1.text = registrationViewModel.formList[indexPath.row]
            cell1.addressTextView.text = registrationViewModel.credentials.homeAddress
            cell1.addressTextView.text = "Enter Home Address"
            cell1.addressTextView.textColor = UIColor.gray
            return cell1
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailsTableCell", for: indexPath) as! DetailsTableCell
        cell.titleLabel.text = registrationViewModel.formList[indexPath.row]
        cell.dataTextField.tag = indexPath.row
        cell.dataTextField.delegate = self
        cell.dataTextField.placeholder = "Enter " + registrationViewModel.placeHolders[indexPath.row]
        cell.dataTextField.inputView = nil
        switch (indexPath.row) {
        case 0:
            cell.dataTextField.text = registrationViewModel.credentials.firstName
        case 1:
            cell.dataTextField.text = registrationViewModel.credentials.lastName
        case 2:
            cell.dataTextField.text = registrationViewModel.credentials.phoneNumebr
            cell.dataTextField.keyboardType = .phonePad
        case 3:
            cell.dataTextField.text = registrationViewModel.credentials.dateOfBirth
            createDatePicker(view: cell.dataTextField)
            cell.dataTextField.inputView = datePicker
        case 4:
            cell.dataTextField.text = registrationViewModel.credentials.emailAddress
            cell.dataTextField.keyboardType = .emailAddress
        case 5:
            print("Address")
        case 6:
            cell.dataTextField.text = registrationViewModel.credentials.createPassword
            cell.dataTextField.isSecureTextEntry = true
        default:
            print("default")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}

// TextField Delegate
extension RegisterViewController: UITextFieldDelegate {
    public func textFieldDidEndEditing(_ textField: UITextField) {
        guard let text = textField.text else {return}
        switch (textField.tag) {
        case 0:
            registrationViewModel.credentials.firstName = text
        case 1:
            registrationViewModel.credentials.lastName = text
        case 2:
            registrationViewModel.credentials.phoneNumebr = text
            if (!text.isValid(phoneNumberValidityType)) {
                Alert.showInvalidPhoneNumberAlert(on: self)
            }
        case 3:
            print("Date of birth")
        case 4:
            registrationViewModel.credentials.emailAddress = text
            if (!text.isValid(emailValidityType)) {
                Alert.showInvalidEmailAlert(on: self)
            }
        case 5:
            registrationViewModel.credentials.homeAddress = text
        case 6:
            registrationViewModel.credentials.createPassword = text
            if (!text.isValid(passwordValidityType)) {
                Alert.showInvalidPasswordAlert(on: self)
            }
        default:
            print("default")
        }
    }
    
    // Creating tool bar
    func createToolBar() -> UIToolbar {
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(donePressed))
        toolBar.setItems([doneButton], animated: true)
        return toolBar
    }
    
    // Creating date picker
    func createDatePicker(view: UITextField) {
        datePicker.preferredDatePickerStyle = .wheels
        datePicker.datePickerMode = .date
        datePicker.maximumDate = Date()
        datePicker.timeZone = TimeZone.current
        view.inputView = datePicker
        view.inputAccessoryView = createToolBar()
    }
    
    // Giving action to done button
    @objc func donePressed() {
        registrationViewModel.credentials.dateOfBirth = self.registrationViewModel.formatDate(date: datePicker.date)
        self.view.endEditing(true)
        tableView.reloadData()
    }
}
