//
//  DetailsTextViewCell.swift
//  Login Form TableView
//
//  Created by Naveen Madhu on 24/06/22.
//

import UIKit

class DetailsTextViewCell: UITableViewCell {
    
    @IBOutlet weak var addressTextView: UITextView!
    @IBOutlet weak var textViewtitleLabe1: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
