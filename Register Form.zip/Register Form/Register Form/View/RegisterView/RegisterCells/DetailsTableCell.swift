//
//  DetailsTableCell.swift
//  Login Form TableView
//
//  Created by Naveen Madhu on 09/06/22.
//

import UIKit

class DetailsTableCell: UITableViewCell {
    
    @IBOutlet weak var dataTextField: UITextField! {
        didSet {
            let grayPlaceholderText = NSAttributedString(string: "Enter Data", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])          // Changing placeholder color
            dataTextField.attributedPlaceholder = grayPlaceholderText
        }
    }
    @IBOutlet weak var titleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}


