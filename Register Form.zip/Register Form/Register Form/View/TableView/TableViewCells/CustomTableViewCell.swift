//
//  CustomTableViewCell.swift
//  RCB Table View
//
//  Created by Naveen Madhu on 26/05/22.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var label: UILabel!
}
