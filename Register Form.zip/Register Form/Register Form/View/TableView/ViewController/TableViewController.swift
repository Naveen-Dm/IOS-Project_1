//
//  ViewController.swift
//  RCB Table View
//
//  Created by Naveen Madhu on 26/05/22.
//

import UIKit

class TableViewController: UIViewController {
    //MARK: IBOUTLET
    @IBOutlet weak var playersTableView: UITableView!
    
    // MARK: Stored Properties
    var playerViewModel: PlayerViewModel = PlayerViewModel()
    
    //MARK: Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Delegate methods and row data for the table view
        playersTableView.delegate = self
        playersTableView.dataSource = self
    }
    
    @IBAction func registerButtonPressed(_ sender: UIButton) {
        let registerModel = storyboard?.instantiateViewController(withIdentifier: "RegisterViewController") as! RegisterViewController
        self.present(registerModel, animated: true)
    }
    
    // To disable the label
    @objc func labelTapped(sender: UITapGestureRecognizer) {
        if sender.state == .ended {
        }
    }
}

//MARK: Table View Delegate Methods and Data Source
extension TableViewController: UITableViewDelegate, UITableViewDataSource {
    // Number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return playerViewModel.numberOfRowsInSection()
    }
    
    // Create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let players = playerViewModel.playerList[indexPath.row]
        let cell = playersTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomTableViewCell         // Create a new cell if needed or reuse an old one
        cell.contentView.layer.cornerRadius = cell.contentView.frame.height / 2
        cell.label.text = players.playerName          // Set the text from the data model
        cell.iconImageView.image = UIImage(named: players.playerImage)
        cell.iconImageView.layer.cornerRadius = cell.iconImageView.frame.height / 2
        // Disable the label (continue line no:25)
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.labelTapped(sender:)))
        cell.label.addGestureRecognizer(tapGesture)
        cell.label.isUserInteractionEnabled = true
        return cell
    }
    
    // Variable height support
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    // Method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let imagePopUp = playerViewModel.playerList[indexPath.row]
        let popUpImageView = storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        popUpImageView.image = UIImage(named: imagePopUp.playerImage)!
        popUpImageView.name = imagePopUp.playerName
        self.present(popUpImageView, animated: false)
    }
}
