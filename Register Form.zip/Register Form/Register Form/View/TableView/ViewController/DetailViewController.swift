//
//  DetailViewController.swift
//  RCB Table View
//
//  Created by Naveen Madhu on 27/05/22.
//

import UIKit

class DetailViewController: UIViewController {
    //MARK: IBOutlet
    @IBOutlet weak var playerLabel: UILabel!
    @IBOutlet weak var playerImage: UIImageView!
    @IBOutlet weak var detailView: UIView!
    
    var image = UIImage()
    var name = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let newLabel = playerLabel {
            newLabel.text = "You selected \(name)"
        }
        if let newImage = playerImage {
            newImage.image = image
        }
    }
    
    // To dissmiss the view when if only empty area is clicked. not in the image view and label
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if touch?.view != detailView {
            self.dismiss(animated: true)
        }
    }
}



