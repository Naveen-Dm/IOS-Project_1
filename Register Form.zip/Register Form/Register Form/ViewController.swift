//
//  ViewController.swift
//  Register Form
//
//  Created by Naveen Madhu on 24/06/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var letsStartButton: UIButton!    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        letsStartButtonDesign()
    }
    
    func letsStartButtonDesign() {        
        // To round the corners
        letsStartButton?.layer.cornerRadius = 20
        letsStartButton?.clipsToBounds = true
        // To provide the shadow
        letsStartButton?.layer.shadowRadius = 10
        letsStartButton?.layer.shadowOpacity = 1.0
        letsStartButton?.layer.shadowOffset = CGSize(width: 3, height: 3)
        letsStartButton?.layer.shadowColor = UIColor.white.cgColor
        letsStartButton?.layer.masksToBounds = false
    }
 
    @IBAction func letsStartButtonPressed(_ sender: UIButton) {
        let loginModel = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.present(loginModel, animated: true)
        
    }
}

