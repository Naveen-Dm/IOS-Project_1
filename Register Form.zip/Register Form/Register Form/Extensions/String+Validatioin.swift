//
//  String+EmailValidatioin.swift
//  Login Form TableView
//
//  Created by Naveen Madhu on 15/06/22.
//

import Foundation

extension String {
    enum ValidityType {
        case firstName
        case lastName
        case phoneNumber
        case dateOfBirth
        case emailAddress
        case homeAddress
        case password
    }
    
    enum Regex: String {
        case firstName = "[A-Za-z]"
        case lastName = "[A-Z]"
        case phoneNumber = "^[6-9]\\d{9}$"
        case dateOfBirth = ""
        case emailAddress = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        case homeAddress = "[A-Za-z0-9]"
        case password = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{8,}$"
    }
    
    func isValid(_ validityType: ValidityType) -> Bool {
        let format = "SELF MATCHES %@"
        var regex = ""
        
        switch validityType {
        case .firstName:
            regex = Regex.firstName.rawValue
        case .lastName:
            regex = Regex.lastName.rawValue
        case .phoneNumber:
            regex = Regex.phoneNumber.rawValue
        case .dateOfBirth:
            regex = Regex.dateOfBirth.rawValue
        case .emailAddress:
            regex = Regex.emailAddress.rawValue
        case .homeAddress:
            regex = Regex.homeAddress.rawValue
        case .password:
            regex = Regex.password.rawValue
        }
        return NSPredicate(format: format, regex).evaluate(with: self)
    }
}



