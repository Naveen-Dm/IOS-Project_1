//
//  TimerViewModel.swift
//  Timer App
//
//  Created by Naveen Madhu on 12/07/22.
//

import Foundation

class TimerViewModel: NSObject {
    var timer = Timer()
    var isTimerRunning = false
    var counter = 0.0
    
    func manipulateTime() -> String {
        counter += 0.1
        let flooredCounter = Int(floor(counter))
        let hour = flooredCounter / 3600
        
        let minute = (flooredCounter % 3600) / 60
        var minuteString = "\(minute)"
        if minute < 10 {
            minuteString = "0\(minute)"
        }
        
        let second = (flooredCounter % 3600) % 60
        var secondString = "\(second)"
        if second < 10 {
            secondString = "0\(second)"
        }
        
        let deciSecond = String(format: "%.1f", counter).components(separatedBy: ".").last!
        return "\(hour):\(minuteString):\(secondString):\(deciSecond)"
    }
    
    func inavalidate() {
        timer.invalidate()
        isTimerRunning = false
    }
}
