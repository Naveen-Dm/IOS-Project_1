//
//  TimeViewController.swift
//  Timer App
//
//  Created by Naveen Madhu on 12/07/22.
//

import UIKit

class TimerViewController: UIViewController {
    
    private var timerViewModel: TimerViewModel = TimerViewModel()
    
    //MARK: - IBOutlets
    @IBOutlet weak var resetButton: UIButton!
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var pauseButton: UIButton!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var circleView: UIView!
    
    //MARK: - Life cycles
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp()
    }
    
    //MARK: - IBActions
    @IBAction func startButtonAction(_ sender: Any) {
        if !timerViewModel.isTimerRunning {
            timerStart()
        }
        startUi()
    }
    
    @IBAction func pauseButtonAction(_ sender: UIButton) {
        timerViewModel.inavalidate()
        pauseUi()
    }
    
    @IBAction func resetButtonAction(_ sender: Any) {
        timerViewModel.inavalidate()
        timerViewModel.counter = 0.0
        timerLabel.text = "00:00:00.0"
        resetUi()
    }
    
    // MARK: Action
    @objc func runTimer() {
        timerLabel.text = timerViewModel.manipulateTime()
    }
}

private extension TimerViewController {
    func initialSetUp() {
        circleView.layer.cornerRadius = circleView.frame.width / 2
        circleView.layer.masksToBounds = true
        circleView.alpha = 0.5
        squareButtonStyle(button: resetButton, title: "", radius: 15)
        resetButton.isHidden = true
        roundButtonStyle(button: startButton, title: "")
        roundButtonStyle(button: pauseButton, title: "")
        pauseButton.isUserInteractionEnabled = false
        pauseButton.alpha = 0.5
    }
    
    func timerStart() {
        timerViewModel.timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(runTimer), userInfo: nil, repeats: true)
        timerViewModel.isTimerRunning = true
    }
    
    func resetUi() {
        circleView.alpha = 0.7
        resetButton.isHidden = true
        pauseButton.isUserInteractionEnabled = false
        pauseButton.alpha = 0.5
        startButton.isEnabled = true
        roundButtonStyle(button: startButton, title: Constant.start)
        roundButtonStyle(button: pauseButton, title: Constant.pause)
    }
    
    func pauseUi() {
        startButton.isEnabled = true
        squareButtonStyle(button: pauseButton, title: "", radius: 15)
        if pauseButton.titleLabel?.text == Constant.resume {
            timerStart()
            roundButtonStyle(button: pauseButton, title: Constant.pause)
        } else {
            timerViewModel.isTimerRunning = false
            pauseButton.setTitle(Constant.resume, for: .normal)
            timerViewModel.inavalidate()
        }
    }
    
    func startUi() {
        circleView.alpha = 1.0
        resetButton.isHidden = false
        roundButtonStyle(button: pauseButton, title: "")
        if startButton.titleLabel?.text == Constant.stop {
            timerViewModel.inavalidate()
            timerViewModel.counter = 0.0
            timerLabel.text = "00:00:00.0"
            roundButtonStyle(button: startButton, title: Constant.start)
            pauseButton.setTitle(Constant.pause, for: .normal)
            pauseButton.isUserInteractionEnabled = false
            pauseButton.alpha = 0.5
        } else {
            squareButtonStyle(button: startButton, title: Constant.stop, radius: 15)
            pauseButton.isUserInteractionEnabled = true
            pauseButton.alpha = 1.0
        }
    }
    
    func roundButtonStyle(button: UIButton, title: String? = "") {
        if title != "" {
            button.setTitle(title, for: .normal)
        }
        button.layer.cornerRadius = button.frame.width / 2
        button.layer.masksToBounds = true
    }
    
    func squareButtonStyle(button: UIButton, title: String? = "", radius: Int) {
        if title != "" {
            button.setTitle(title, for: .normal)
        }
        button.layer.cornerRadius = CGFloat(radius)
        button.layer.masksToBounds = true
    }
}
