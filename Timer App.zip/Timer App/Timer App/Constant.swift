//
//  Constant.swift
//  Timer App
//
//  Created by Naveen Madhu on 15/07/22.
//

import Foundation

struct Constant {
    static let start = "START"
    static let stop = "STOP"
    static let resume = "RESUME"
    static let pause = "PAUSE"
}
