//
//  QuizModel.swift
//  Quizz
//
//  Created by Naveen Madhu on 21/09/22.
//

import Foundation

class Question {
    let text: String
    let answer: String
    
    init(question: String, answer: String) {
        self.text = question
        self.answer = answer
    }
}
