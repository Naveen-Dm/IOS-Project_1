//
//  ViewController.swift
//  Quizz
//
//  Created by Naveen Madhu on 20/09/22.
//

import UIKit

class QuizViewController: UIViewController {

    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var trueButton: UIButton!
    @IBOutlet weak var falseButton: UIButton!
    
    var quizViewModel = QuizViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        updateUI()
        initialSetup()
        
    }
    
    func initialSetup() {
        trueButton.layer.cornerRadius = 25.0
        trueButton.layer.borderWidth = 5
        trueButton.layer.borderColor = UIColor(red: 200.0/255.0, green: 143.0/255.0, blue: 127.0/255.0, alpha: 1.0).cgColor
        trueButton.clipsToBounds = true
        
        falseButton.layer.cornerRadius = 25.0
        falseButton.layer.borderWidth = 5
        falseButton.layer.borderColor = UIColor(red: 200.0/255.0, green: 143.0/255.0, blue: 127.0/255.0, alpha: 1.0).cgColor
        falseButton.clipsToBounds = true
    }


    @IBAction func answerButtonPressed(_ sender: UIButton) {
        
        let userAnswer = sender.currentTitle!
        let userGotItRight =  quizViewModel.checkAnswer(userAnswer)
        
        if userGotItRight {
            sender.backgroundColor = UIColor.green
        } else {
            sender.backgroundColor = UIColor.red
        }
        
        quizViewModel.nextQuestion()
        
        Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(updateUI), userInfo: nil, repeats: false)
        
    }
    
    @objc func updateUI() {
        questionLabel.text = quizViewModel.getQuestionText()
        progressBar.progress = quizViewModel.getProgress()
        scoreLabel.text = "Score: \(quizViewModel.getScore())"
        trueButton.backgroundColor = UIColor.clear
        falseButton.backgroundColor = UIColor.clear
    }
}

