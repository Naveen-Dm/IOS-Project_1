//
//  PlayerViewModel.swift
//  RCB Table View
//
//  Created by Naveen Madhu on 30/05/22.
//

import Foundation

class Players: NSObject {
    let playerName: String
    let playerImage: String
    
    init(playerName: String, playerImage: String) {
        self.playerName = playerName
        self.playerImage = playerImage
    }
}
