//
//  PlayerViewModel.swift
//  RCB Table View
//
//  Created by Naveen Madhu on 30/05/22.
//

import Foundation

class PlayerViewModel: NSObject {
    // Properties
    var playerList = Array<Players>()
    
    override init() {
        let player1 = Players(playerName: "Virat Kohli", playerImage: "virat")
        let player2 = Players(playerName: "Glenn Maxwell", playerImage: "maxwell")
        let player3 = Players(playerName: "Mohammad Siraj", playerImage: "siraj")
        let player4 = Players(playerName: "Faf Du Plessis", playerImage: "faf du plessis")
        let player5 = Players(playerName: "Harshal Patel", playerImage: "harshel patel")
        let player6 = Players(playerName: "Wanindu Hasaranga", playerImage: "hasranga")
        let player7 = Players(playerName: "Dinesh Karthik", playerImage: "dinesh karthik")
        let player8 = Players(playerName: "Rajat Patidar", playerImage: "rajat patidar")
        let player9 = Players(playerName: "Josh Hazlewood", playerImage: "hazlewood")
        let player10 = Players(playerName: "Mahipal Lomror", playerImage: "lamror")
        let player11 = Players(playerName: "Shahbaz Ahmed", playerImage: "shabhaz")

        playerList.append(player1)
        playerList.append(player2)
        playerList.append(player3)
        playerList.append(player4)
        playerList.append(player5)
        playerList.append(player6)
        playerList.append(player7)
        playerList.append(player8)
        playerList.append(player9)
        playerList.append(player10)
        playerList.append(player11)
    }
    
    func numberOfRowsInSection()  -> Int{
        return playerList.count
    }
}
