//
//  DogViewModel.swift
//  ScrollView
//
//  Created by Naveen Madhu on 09/08/22.
//

import Foundation
