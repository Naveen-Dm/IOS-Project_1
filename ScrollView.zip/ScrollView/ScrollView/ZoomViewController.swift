//
//  ZoomViewController.swift
//  ScrollView
//
//  Created by Naveen Madhu on 10/08/22.
//

import UIKit

class ZoomViewController: UIViewController {
    
    @IBOutlet weak var zoomScrollView: UIScrollView!
    @IBOutlet weak var zoomImageView: UIImageView!
    
    var image = UIImage()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        zoomScrollView?.delegate = self
        zoomScrollView?.maximumZoomScale = 0.5
        
        if let newImage = zoomImageView {
            newImage.image = image
        }
    }
}
extension ZoomViewController: UIScrollViewDelegate {
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return zoomImageView
    }
}







