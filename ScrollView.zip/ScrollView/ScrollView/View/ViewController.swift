//
//  ViewController.swift
//  ScrollView
//
//  Created by Naveen Madhu on 08/08/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    @IBOutlet weak var imageView3: UIImageView!
    @IBOutlet weak var imageView4: UIImageView!
    @IBOutlet weak var imageView5: UIImageView!
    @IBOutlet weak var imageView6: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        imageTapped()
    }
    
    func imageTapped() {
        imageView1.isUserInteractionEnabled = true
        imageView1.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(imageTap)))
    }
    
    @objc func imageTap() {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ZoomViewController") as! ZoomViewController
        vc.image = imageView1.image ?? UIImage()
        self.present(vc, animated: true, completion: nil)
    }
}





































//for image in imageArray {
//    let imageView = UIImageView(image: image)
//    imageContainerView.addSubview(imageView)
//    imageViews.append(imageView)
//}
//
//override func viewDidLayoutSubviews() {
//
//
//    for (index,imageView) in imageViews.enumerate() {
//        imageView.frame = CGRectMake(CGFloat(index)*scrollView.frame.size.width, 0, scrollView.frame.size.width, scrollView.frame.size.height)
//    }
//
//    let imageArrayCount = CGFloat(imageArray.count)
//
//    scrollView.contentSize = CGSizeMake(scrollView.frame.size.width *  imageArrayCount, scrollView.frame.size.height)
//
//}
