//
//  LocationData.swift
//  WeatherApp
//
//  Created by Naveen Madhu on 29/09/22.
//

import Foundation

struct LocationData: Codable{
    let region: String
    let country: String
    let localtime:String
}
