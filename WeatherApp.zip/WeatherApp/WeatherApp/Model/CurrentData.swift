//
//  CurrentData.swift
//  WeatherApp
//
//  Created by Naveen Madhu on 29/09/22.
//

import Foundation

struct CurrentData: Codable {
    let last_updated: String
    let temp_c: Float
    let wind_kph: Float
    let humidity: Int
}
