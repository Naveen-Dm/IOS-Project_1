//
//  WeatherData.swift
//  WeatherApp
//
//  Created by Naveen Madhu on 29/09/22.
//

import Foundation
struct WeatherData: Codable {
    let location: LocationData
    let current: CurrentData
}
