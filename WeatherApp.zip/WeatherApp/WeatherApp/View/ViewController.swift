//
//  ViewController.swift
//  WeatherApp
//
//  Created by Naveen Madhu on 28/09/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var windLabel: UILabel!
    @IBOutlet weak var countryLabel: UILabel!
    @IBOutlet weak var temparatureLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var refreshButton: UIButton!
    @IBOutlet weak var updatedTimeLabel: UILabel!
    @IBOutlet weak var localTimeLabel: UILabel!
    @IBOutlet weak var Image: UIImageView!
    @IBOutlet weak var regionLabel: UILabel!
    
    let url = "http://api.weatherapi.com/v1/current.json?key=33433cc10b3241f18b0124302223009&q=India&aqi=no"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        uiSetup()
        fetchData()
    }
    
    private func uiSetup() {
        refreshButton.layer.cornerRadius = 15
        Image.layer.cornerRadius = 20
        Image.clipsToBounds = true
    }
    
    private func fetchData(){
        let url = URL(string: url)
        let dataTask = URLSession.shared.dataTask(with: url!, completionHandler: {
            (data, response, error) in
            guard let  data = data, error == nil else
            {
                print("Error Ocurred while Acessing Data with Url")
                return
            }
            var fullWeatherData: WeatherData?
            do
            {
                fullWeatherData = try JSONDecoder().decode(WeatherData.self, from: data)
            }
            catch
            {
                print("Error Occured While Acessing Json\(error)")
            }
            DispatchQueue.main.sync {
                
                self.windLabel.text = "Wind (Km/Hr): \(fullWeatherData!.current.wind_kph)"
                self.countryLabel.text = "Country: \(fullWeatherData!.location.country)"
                self.humidityLabel.text = "Humidity: \(fullWeatherData!.current.humidity)"
                self.temparatureLabel.text = "Temparature: \(fullWeatherData!.current.temp_c)"
                self.updatedTimeLabel.text = "Updated time: \(fullWeatherData!.current.last_updated)"
                self.localTimeLabel.text = "Local time: \(fullWeatherData!.location.localtime)"
                self.regionLabel.text = "Region: \(fullWeatherData!.location.region)"
            }
        })
        dataTask.resume()
    }
    
    @IBAction func refreshButtonPressed(_ sender: Any) {
        fetchData()
    }
    
}
