//
//  JumpTableViewCell.swift
//  Jump Cell
//
//  Created by Naveen Madhu on 23/09/22.
//

import UIKit

class JumpTableViewCell: UITableViewCell {
    
    @IBOutlet weak var label: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
