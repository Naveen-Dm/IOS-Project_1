//
//  ViewController.swift
//  Jump Cell
//
//  Created by Naveen Madhu on 23/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var jumpButotn: UIButton!
    @IBOutlet weak var tableView: UITableView!
    var index = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.delegate = self
        tableView.dataSource = self
    }

    @IBAction func jumpButtonPressed(_ sender: Any) {
        
        let fromIndexPath = IndexPath(row: 4, section: 0)
//        let toIndexPath = IndexPath(row: 0, section: 0)
//        tableView.moveRow(at: fromIndexPath, to: toIndexPath)
        tableView.scrollToRow(at: fromIndexPath, at: .top, animated: true)
    }
    
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! JumpTableViewCell
        cell.label.text = String(indexPath.row+1)
        return cell
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
}



