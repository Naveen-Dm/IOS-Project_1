//
//  ViewModel.swift
//  TableView
//
//  Created by Naveen Madhu on 21/10/22.
//

import Foundation

class ViewModel: NSObject {
    // Properties
    var viewList = Array<Players>()
    
    override init() {
        let list1 = Players(playerName: "Naveen")
        let list2 = Players(playerName: "Mohan")
        let list3 = Players(playerName: "Shashank")
        let list4 = Players(playerName: "Suma")
        let list5 = Players(playerName: "Madhu")
        
        let list6 = Players(playerName: "Shivam")
        let list7 = Players(playerName: "Viraaj")
        let list8 = Players(playerName: "Afzal")
        let list9 = Players(playerName: "Vijay")
        let list10 = Players(playerName: "Gayathri")
        
        let list11 = Players(playerName: "Afzal")
        let list12 = Players(playerName: "Manja")
        let list13 = Players(playerName: "Sudeep")
        let list14 = Players(playerName: "Dharshan")
        let list15 = Players(playerName: "Raju")
        
        viewList.append(list1)
        viewList.append(list2)
        viewList.append(list3)
        viewList.append(list4)
        viewList.append(list5)
       
        viewList.append(list6)
        viewList.append(list7)
        viewList.append(list8)
        viewList.append(list9)
        viewList.append(list10)
        
        viewList.append(list11)
        viewList.append(list12)
        viewList.append(list13)
        viewList.append(list14)
        viewList.append(list15)
    }
    
    func numberOfRowsInSection()  -> Int{
        return viewList.count
    }
}
