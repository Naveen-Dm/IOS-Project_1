//
//  Model.swift
//  TableView
//
//  Created by Naveen Madhu on 21/10/22.
//

import Foundation


class Players: NSObject {
    let playerName: String
    
    init(playerName: String) {
        self.playerName = playerName
    }
}
