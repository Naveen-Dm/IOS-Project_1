//
//  ViewController.swift
//  TableView
//
//  Created by Naveen Madhu on 21/10/22.
//

import UIKit

class ViewController: UIViewController {
    
    let viewModel: ViewModel = ViewModel()
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.delegate = self
        tableView.dataSource = self
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfRowsInSection()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let players = viewModel.viewList[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        cell.label.text = players.playerName
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "This is Header"
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let footerView = UIView()
        footerView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: 100)
        let button = UIButton()
        button.frame = CGRect(x: 0, y: -20, width: 425, height: 50)
        button.setTitle("Footer Button", for: .normal)
        button.backgroundColor = UIColor.systemBlue
        footerView.addSubview(button)
        return footerView
    }
}
