//
//  ViewController.swift
//  Login Form TableView
//
//  Created by Naveen Madhu on 09/06/22.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    // Properties
    var registrationViewModel: RegistrationViewModel = RegistrationViewModel()
    var detailsTextViewCell: DetailsTextViewCell = DetailsTextViewCell()
    let emailValidityType: String.ValidityType = .emailAddress
    let phoneNumberValidityType: String.ValidityType = .phoneNumber
    let passwordValidityType: String.ValidityType = .password
    let datePicker = UIDatePicker()
    var audio: AVAudioPlayer?
    
    // IBOutlet
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var regButton: UIButton!
    @IBOutlet weak var registerErrorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerCell()
        initialSetUp()
    }

    private func initialSetUp() {
        regButton.layer.cornerRadius = 20
        regButton.clipsToBounds = true
        // To provide the shadow
        regButton.layer.shadowRadius = 10
        regButton.layer.shadowOpacity = 1.0
        regButton.layer.shadowOffset = CGSize(width: 3, height: 3)
        regButton.layer.shadowColor = UIColor.white.cgColor
        regButton.layer.masksToBounds = false
    }
    
    private func registerCell(){
        tableView.register(UINib(nibName: "DetailsTableCell", bundle: nil), forCellReuseIdentifier: "DetailsTableCell")
        tableView.register(UINib(nibName: "DetailsTextViewCell", bundle: nil), forCellReuseIdentifier: "DetailsTextViewCell")
    }
    
    @IBAction func registerButton(_ sender: Any) {
    }
}

// TableView Delegates and data source
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return registrationViewModel.formList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if (indexPath.row == 5) {
            let cell1 = tableView.dequeueReusableCell(withIdentifier: "DetailsTextViewCell", for: indexPath) as! DetailsTextViewCell
            cell1.addressTextView.text = registrationViewModel.credentials.homeAddress
            cell1.textViewtitleLabe1.text = registrationViewModel.formList[indexPath.row]
            cell1.addressTextView.text = "Enter Home Address"
            cell1.addressTextView.textColor = UIColor.gray
            return cell1
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailsTableCell", for: indexPath) as! DetailsTableCell
        cell.titleLabel.text = registrationViewModel.formList[indexPath.row]
        cell.dataTextField.tag = indexPath.row
        cell.dataTextField.delegate = self
        cell.dataTextField.placeholder = "Enter " + registrationViewModel.placeHolders[indexPath.row]
        cell.dataTextField.inputView = nil
        switch (indexPath.row) {
        case 0:
            cell.dataTextField.text = registrationViewModel.credentials.firstName
        case 1:
            cell.dataTextField.text = registrationViewModel.credentials.lastName
        case 2:
            cell.dataTextField.text = registrationViewModel.credentials.phoneNumebr
            cell.dataTextField.keyboardType = .phonePad
        case 3:
            cell.dataTextField.text = registrationViewModel.credentials.dateOfBirth
            createDatePicker(view: cell.dataTextField)
            cell.dataTextField.inputView = datePicker
        case 4:
            cell.dataTextField.text = registrationViewModel.credentials.emailAddress
            cell.dataTextField.keyboardType = .emailAddress
        case 5:
//            cell.dataTextField.text = registrationViewModel.credentials.homeAddress
            print("Address")
        case 6:
            cell.dataTextField.text = registrationViewModel.credentials.password
        default:
            print("default")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}

// TextField Delegate
extension ViewController: UITextFieldDelegate {
    public func textFieldDidEndEditing(_ textField: UITextField) {
        guard let text = textField.text else {return}
        switch (textField.tag) {
        case 0:
            registrationViewModel.credentials.firstName = text
        case 1:
            registrationViewModel.credentials.lastName = text
        case 2:
            registrationViewModel.credentials.phoneNumebr = text
            if (!text.isValid(phoneNumberValidityType)) {
                Alert.showInvalidPhoneNumberAlert(on: self)
            }
        case 3:
            print("Date of birth")
        case 4:
            registrationViewModel.credentials.emailAddress = text
            if (!text.isValid(emailValidityType)) {
                Alert.showInvalidEmailAlert(on: self)
            }
        case 5:
            registrationViewModel.credentials.homeAddress = text
        case 6:
            registrationViewModel.credentials.password = text
            if (!text.isValid(passwordValidityType)) {
                Alert.showInvalidPasswordAlert(on: self)
            }
        default:
            print("default")
        }
        print("Tag: \(textField.tag), text  = \(String(describing: textField.text))")
    }
    
    // Creating tool bar
    func createToolBar() -> UIToolbar {
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(donePressed))
        toolBar.setItems([doneButton], animated: true)
        return toolBar
    }
    
    // Creating date picker
    func createDatePicker(view: UITextField) {
        datePicker.preferredDatePickerStyle = .wheels
        datePicker.datePickerMode = .date
        datePicker.maximumDate = Date()
        datePicker.timeZone = TimeZone.current
        view.inputView = datePicker
        view.inputAccessoryView = createToolBar()
    }
    
    // Giving action to done button
    @objc func donePressed() {
        registrationViewModel.credentials.dateOfBirth = self.registrationViewModel.formatDate(date: datePicker.date)
        self.view.endEditing(true)
        tableView.reloadData()
    }
}

extension ViewController: UITextViewDelegate {
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text == "Enter Home Address" {
            textView.text = ""
            textView.textColor = UIColor.white
        }
    }

    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text == "" {
            textView.resignFirstResponder()
        }
        return true
    }
}
