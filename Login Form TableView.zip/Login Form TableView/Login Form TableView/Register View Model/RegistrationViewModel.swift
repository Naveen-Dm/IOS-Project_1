//
//  RegistrationViewModel.swift
//  Login Form TableView
//
//  Created by Naveen Madhu on 09/06/22.
//

import Foundation
import UIKit

class RegistrationViewModel {
        
    var formList = ["First Name", "Last Name", "Phone number", "Date of birth", "Email", "Home Address", "Password"]
    var placeHolders = ["First Name", "Last Name", "Phone number", "Date of birth", "Email", "Home Address", "Password"]
    let dateFormatter = DateFormatter()
    
    //Here our model notify that was updated
    var credentials : Credentials = Credentials()
    
    // Creating format for date picker
    func formatDate(date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM dd yyyy"
        return formatter.string(from: date)
    }
}





