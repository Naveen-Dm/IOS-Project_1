//
//  RegistrationModel.swift
//  Login Form TableView
//
//  Created by Naveen Madhu on 09/06/22.
//

import Foundation

class Credentials: NSObject {
    var firstName: String = ""
    var lastName: String = ""
    var phoneNumebr: String = ""
    var dateOfBirth: String = ""
    var emailAddress: String = ""
    var homeAddress: String = ""
    var password: String = ""
}
