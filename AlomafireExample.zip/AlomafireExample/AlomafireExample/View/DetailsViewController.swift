//
//  DetailsViewController.swift
//  AlomafireExample
//
//  Created by Naveen Madhu on 20/07/22.
//

import UIKit

class DetailsViewController: UIViewController {
    
    //MARK: IBOUTLET
    @IBOutlet weak var filmNameLabel: UILabel!
    @IBOutlet weak var episodeLabel: UILabel!
    @IBOutlet weak var directorLabel: UILabel!
    @IBOutlet weak var directorNameLabel: UILabel!
    @IBOutlet weak var producerLabel: UILabel!
    @IBOutlet weak var producerNameLabel: UILabel!
    @IBOutlet weak var releaseLabel: UILabel!
    @IBOutlet weak var releaseDateLabel: UILabel!
    @IBOutlet weak var overviewView: UITextView!
    @IBOutlet weak var posterImageView: UIImageView!
    
    // MARK: Stored Properties
    private var posters: Poster?
    private var filmModel: FilmModel?
    
    //MARK: Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        initialization()
        posterImageView.load(url: posters!.posterImage) // Loading image in the DetailsViewController
    }
    
    //MARK: IBAction
    @IBAction func backButtonPressed(_ sender: Any) {
        self.presentingViewController?.dismiss(animated: true)
    }
}
    
extension DetailsViewController {
    
    // Assigning values to the labels
    private func initialization() {
        filmNameLabel.text = filmModel?.titleLabelText
        episodeLabel.text = filmModel?.subtitleLabelText
        directorLabel.text = filmModel?.directorItem.label
        directorNameLabel.text = filmModel?.directorItem.value
        producerLabel.text = filmModel?.producerItem.label
        producerNameLabel.text = filmModel?.producerItem.value
        releaseLabel.text = filmModel?.releaseItem.label
        releaseDateLabel.text = filmModel?.releaseItem.value
        overviewView.text = filmModel?.overview
    }
    
    func detailInitialization(item: FilmModel, image: Poster) {
        filmModel = item
        posters = image
    }
}
