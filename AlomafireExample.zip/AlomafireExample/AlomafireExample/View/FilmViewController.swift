//
//  ViewController.swift
//  AlomafireExample
//
//  Created by Naveen Madhu on 19/07/22.
//

import UIKit
import Alamofire

class FilmViewController: UIViewController {
    
    //MARK: IBOUTLET
    @IBOutlet weak var filmTableView: UITableView!
    
    // MARK: Stored Properties
    private var filmViewModel = FilmViewModel()

    //MARK: Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        fetchAllFilms()
        self.showSpinner()
    }
}

private extension FilmViewController {
    func fetchAllFilms() {
        filmViewModel.fetchAllFilm { isSuccess in
            if isSuccess{
                self.filmTableView.reloadData()
                self.removeSpinner()
            } else {
                Alert.showAlert(on: self)
            }
        }
    }
}

//MARK: Table View Delegate Methods and Data Source
extension FilmViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filmViewModel.items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = filmViewModel.items[indexPath.row]
        let posters = filmViewModel.posterList[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! CustomTableViewCell
        cell.contentView.layer.cornerRadius = cell.contentView.frame.height / 2
        cell.labelInitialization(item: item)
        cell.imageInitialization(posters: posters)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedItem = filmViewModel.items[indexPath.row]
        let posters = filmViewModel.posterList[indexPath.row]
        let destinationVc = storyboard?.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        destinationVc.detailInitialization(item: selectedItem, image: posters)
        self.present(destinationVc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
}





























































//private extension FilmViewController {
//    func fetchFilms() {
////        filmViewModel.fetch()
//        let request = AF.request(Constant.url)
//        request.responseDecodable(of: Films.self) { (response) in
//            guard let films = response.value else {return}
//            self.filmViewModel.items = films.all
//            self.filmTableView.reloadData()
//        }
//    }
//}

