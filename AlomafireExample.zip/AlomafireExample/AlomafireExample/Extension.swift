//
//  Extension.swift
//  AlomafireExample
//
//  Created by Naveen Madhu on 26/07/22.
//

import Foundation
import UIKit

extension UIImageView{
    func load(url: String){
        guard let url = URL(string: url)else{
            return
        }
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url){
                if let image = UIImage(data: data){
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}

private var vSpinner : UIView?

extension FilmViewController {
    func showSpinner() {
        vSpinner = UIView(frame: self.view.bounds)
        vSpinner?.backgroundColor = UIColor.init(red: 0.5, green: 0.5, blue: 0.5, alpha: 0.5)
        let ai = UIActivityIndicatorView(style: .large)
        ai.center = vSpinner!.center
        ai.startAnimating()
        vSpinner?.addSubview(ai)
        self.view.addSubview(vSpinner!)
    }
    
    func removeSpinner() {
        DispatchQueue.main.async {
            vSpinner?.removeFromSuperview()
            vSpinner = nil
        }
    }
}

