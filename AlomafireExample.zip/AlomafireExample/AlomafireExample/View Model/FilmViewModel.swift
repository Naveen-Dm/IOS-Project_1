//
//  ViewModel.swift
//  AlomafireExample
//
//  Created by Naveen Madhu on 19/07/22.
//

import Foundation
import Alamofire

class FilmViewModel: NSObject {
    
    // Properties
    var posterList = Array<Poster>()
    var items: [FilmModel] = []
    var webService = WebService()
    
    override init() {
        let poster1 = Poster(posterImage: "https://img1.hotstarext.com/image/upload/f_auto,t_hcdl/sources/r1/cms/prod/3067/663067-h")
        let poster2 = Poster(posterImage: "https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/20092B5CAD2B364BFFFB162D8BA70D8F9BB2A51A05160F19AF98293C33171B0D/scale?width=1200&aspectRatio=1.78&format=jpeg")
        let poster3 = Poster(posterImage: "https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/55FA06C7A7F7624BC43772D4F5B38FB7322B0B467671177514B2662BE4315EB7/scale?width=1200&aspectRatio=1.78&format=jpeg")
        let poster4 = Poster(posterImage: "https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/D64BD30F181B9DF24630FEDF97B0F68B1A1BB2C6E339E8C58C7ABCDD7B06F60E/scale?width=1200&aspectRatio=1.78&format=jpeg")
        let poster5 = Poster(posterImage: "https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/19F23D15DB764E10EB4F2B759F520BB2F0DA28043099048B6C97367679F8348B/scale?width=1200&aspectRatio=1.78&format=jpeg")
        let poster6 = Poster(posterImage: "https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/A1D55C8D5715EE355BCB9AF78027A3128243262C9FF7E211CFF9834968363D9D/scale?width=1200&aspectRatio=1.78&format=jpeg")
    
        posterList.append(poster1)
        posterList.append(poster2)
        posterList.append(poster3)
        posterList.append(poster4)
        posterList.append(poster5)
        posterList.append(poster6)
    }
    
    func fetchAllFilm(completionHandler: @escaping ((Bool) -> ())) {
        webService.fetchFilm { result in
            switch result {
            case .success(let items):
                self.items = items.all
                completionHandler(true)
            case .failure(let error):
                print(error.localizedDescription)
                completionHandler(false)
            }
        }
    }
}

