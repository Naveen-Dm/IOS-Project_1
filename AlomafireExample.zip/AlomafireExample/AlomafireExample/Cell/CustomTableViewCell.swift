//
//  CustomTableViewCell.swift
//  AlomafireExample
//
//  Created by Naveen Madhu on 20/07/22.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    
    //MARK: IBOUTLET
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subTitleLabel: UILabel!
    @IBOutlet weak var posterImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}

extension CustomTableViewCell {
    // Assigning values to the labels in the cell
    func labelInitialization(item: FilmModel){
        titleLabel.text = item.titleLabelText
        subTitleLabel.text = item.subtitleLabelText
    }
    
    // Loading image to the imageView in the cell
    func imageInitialization(posters: Poster) {
        posterImageView.load(url: posters.posterImage)
        posterImageView.layer.cornerRadius = 10
    }
}
