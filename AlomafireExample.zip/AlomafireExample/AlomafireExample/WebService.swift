//
//  WebService.swift
//  AlomafireExample
//
//  Created by Naveen Madhu on 01/08/22.
//

import Foundation
import Alamofire

enum apiError: Error {
    case noData
    case apiFailed
    case parsingFailed
    case badUrl
}

class WebService {
    func fetchFilm(completionHandler: @escaping (Result<Films,apiError>) -> (Void)) {
        let request = AF.request(Constant.url)
        request.responseDecodable(of: Films.self) { (response) in
            guard let films = response.value else {
                completionHandler(.failure(apiError.apiFailed))
                return
            }
            completionHandler(.success(films))
        }
    }
}




























































//class WebService {
//    func fetchFilm(completionHandler: @escaping (Result<Films,apiError>) -> (Void)) {
//        guard let url = URL(string: Constant.url) else {
//            completionHandler(.failure(apiError.badUrl))
//            return
//        }
//
//        URLSession.shared.dataTask(with: url) { data, response, error in
//            guard let data = data, error == nil else {
//                completionHandler(.failure(apiError.apiFailed))
//                return
//            }
//
//            do {
//                let films = try JSONDecoder().decode(Films.self, from: data)
//                DispatchQueue.main.async {
//                    completionHandler(.success(films))
//                }
//            } catch(let error) {
//                print(error.localizedDescription)
//            }
//        }.resume()
//    }
//}
