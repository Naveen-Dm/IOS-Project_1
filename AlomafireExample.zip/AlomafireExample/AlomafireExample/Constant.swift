//
//  Constant.swift
//  AlomafireExample
//
//  Created by Naveen Madhu on 26/07/22.
//

import Foundation

struct Constant {
    static let url = "https://swapi.dev/api/films"
}



