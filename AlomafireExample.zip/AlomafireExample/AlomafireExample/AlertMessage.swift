//
//  AlertMessage.swift
//  AlomafireExample
//
//  Created by Naveen Madhu on 03/08/22.
//

import Foundation
import UIKit

struct Alert {
    
    private static func showAlert(on vc: FilmViewController, with title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        vc.present(alert, animated: true)
    }
    
    static func showAlert(on vc: FilmViewController) {
        showAlert(on: vc, with: "Error", message: "Soomething went wrong")
    }
}
