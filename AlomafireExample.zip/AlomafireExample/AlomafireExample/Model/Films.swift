//
//  Films.swift
//  AlomafireExample
//
//  Created by Naveen Madhu on 19/07/22.
//

import Foundation

struct Films: Decodable {
  let count: Int
  let all: [FilmModel]
  
  enum CodingKeys: String, CodingKey {
    case count
    case all = "results"
  }
}
