//
//  Model.swift
//  AlomafireExample
//
//  Created by Naveen Madhu on 19/07/22.
//

import Foundation
import UIKit

struct FilmModel: Decodable {
    let id: Int
    let title: String
    let openingCrawl: String
    let director: String
    let producer: String
    let releaseDate: String
    let starships: [String]
    
    enum CodingKeys: String, CodingKey {
        case id = "episode_id"
        case title
        case openingCrawl = "opening_crawl"
        case director
        case producer
        case releaseDate = "release_date"
        case starships
    }
}

extension FilmModel {
    var titleLabelText: String {
        title
    }
    
    var subtitleLabelText: String {
        "Episode \(String(id))"
    }
    
    var directorItem: (label: String, value: String) {
        ("DIRECTOR", director)
    }
    
    var producerItem: (label: String, value: String) {
        ("PRODUCER", producer)
    }
    
    var releaseItem: (label: String, value: String) {
        ("RELEASE DATE", releaseDate)
    }
    
    var overview: String {
        openingCrawl
    }
    
    var listItems: [String] {
        starships
    }
    
}

class Poster: NSObject {
    let posterImage: String
    
    init(posterImage: String) {
        self.posterImage = posterImage
    }
}


