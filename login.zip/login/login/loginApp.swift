//
//  loginApp.swift
//  login
//
//  Created by Naveen Madhu on 17/05/22.
//

import SwiftUI

@main
struct loginApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
