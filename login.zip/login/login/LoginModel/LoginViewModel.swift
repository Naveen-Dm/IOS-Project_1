//
//  LoginViewModel.swift
//  login
//
//  Created by Naveen Madhu on 18/05/22.
//

import Foundation
import UIKit
 

class LoginViewModel {
    
    public var username = ""
    public var password = ""
    public var wrongUsername = 0
    public var wrongPassword = 0
    public var showingLoginScreen = false 
    
    func authenticateUser(username: String, password: String) {
        if username.lowercased() == "naveen" {
            wrongUsername = 0
            if password.lowercased() == "abc123" {
                wrongPassword = 0
                showingLoginScreen = true
            } else {
                wrongPassword = 2
            }
        } else {
            wrongUsername = 2
        }
    }
}

