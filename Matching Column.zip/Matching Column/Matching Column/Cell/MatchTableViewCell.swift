//
//  MatchTableViewCell.swift
//  Matching Column
//
//  Created by Naveen Madhu on 22/09/22.
//

import UIKit

class MatchTableViewCell: UITableViewCell {
    
    @IBOutlet weak var label: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
