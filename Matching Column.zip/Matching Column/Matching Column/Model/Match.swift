//
//  Match.swift
//  Matching Column
//
//  Created by Naveen Madhu on 22/09/22.
//

import Foundation

class Match: NSObject {
    let colorName: String
    
    init(colorName: String) {
        self.colorName = colorName
    }
}
