//
//  ViewController.swift
//  Matching Column
//
//  Created by Naveen Madhu on 22/09/22.
//

import UIKit

class MatchViewController: UIViewController {
    
    var matchViewModel: MatchViewModel = MatchViewModel()
    
    @IBOutlet weak var colorTableView: UITableView!
    @IBOutlet weak var colorScrollView: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        colorTableView.delegate = self
        colorTableView.dataSource = self
       
    }
}

extension MatchViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return matchViewModel.colorList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let color = matchViewModel.colorList[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MatchTableViewCell
        cell.label.text = color.colorName
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}
