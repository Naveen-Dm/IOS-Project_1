//
//  MatchViewModel.swift
//  Matching Column
//
//  Created by Naveen Madhu on 22/09/22.
//

import Foundation

class MatchViewModel: NSObject {
    var colorList = Array<Match>()
    
    override init() {
        let color1 = Match(colorName: "Green")
        let color2 = Match(colorName: "Indigo")
        let color3 = Match(colorName: "Orange")
        let color4 = Match(colorName: "Pink")
        let color5 = Match(colorName: "Purple")
        let color6 = Match(colorName: "Red")
        let color7 = Match(colorName: "Yellow")
        
        colorList.append(color1)
        colorList.append(color2)
        colorList.append(color3)
        colorList.append(color4)
        colorList.append(color5)
        colorList.append(color6)
        colorList.append(color7)

    }
}
