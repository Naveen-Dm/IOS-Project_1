//
//  Model.swift
//  Custom Delegate
//
//  Created by Naveen Madhu on 05/07/22.
//

import Foundation

class Todo: NSObject {
    let title: String
    let describe: String
    
    init(title: String, describe: String) {
        self.title = title
        self.describe = describe
    }
    
}
