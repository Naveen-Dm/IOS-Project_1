//
//  CustomTableViewCell.swift
//  Custom Delegate
//
//  Created by Naveen Madhu on 05/07/22.
//

import UIKit

//MARK: protocol created
protocol CustomTableViewCellProtocol: AnyObject {
    func didDeleteCell(_ sender: CustomTableViewCell)
    func didEditOrSaveCell(_ sender: CustomTableViewCell)
}

class CustomTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionTextView: UITextView!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var editButton: UIButton!

    // delegate variable create for protocol
    weak var delegate: CustomTableViewCellProtocol?
    var index: Int!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBAction func deleteButton(_ sender: Any) {
        delegate?.didDeleteCell(self)
    }
    
    @IBAction func editOrSaveButton(_ sender: UIButton) {
        delegate?.didEditOrSaveCell(self)
        
//        if sender.isSelected {
//            descriptionTextView.isEditable = false
//            editButton.setTitle("Edit", for: .normal)
//        } else {
//            descriptionTextView.isEditable = true
//            editButton.setTitle("Save", for: .normal)
//        }
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
