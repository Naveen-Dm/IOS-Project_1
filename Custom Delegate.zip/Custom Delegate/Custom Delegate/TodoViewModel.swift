//
//  ViewModel.swift
//  Custom Delegate
//
//  Created by Naveen Madhu on 05/07/22.
//

import Foundation

class TodoViewModel: NSObject {
    // Properties
    var todoList = Array<Todo>()
    
    override init() {
        let list1 = Todo(title: "Shopping", describe: "Work hard so you can shop harder.")
        let list2 = Todo(title: "Drink water", describe: "Water is the best of all things.")
        let list3 = Todo(title: "Go for walk", describe: "Walking is the best possible exercise. Habituate yourself to walk very far.")
        let list4 = Todo(title: "eat food", describe: "Water is the best of all things.")
        let list5 = Todo(title: "go for gym", describe: "Water is the best of all things.")

        todoList.append(list1)
        todoList.append(list2)
        todoList.append(list3)
        todoList.append(list4)
        todoList.append(list5)
    }
    
    func updateArreyData(text: String, index: Int) {
//            guard let title = sender.titleLabel.text, let describtion = sender.descriptionTextView.text else {return}
//            let object = Todo(title: title, describe: describtion)
//            todoViewModel.todoList.remove(at: sender.index)
//            todoViewModel.todoList.insert(object, at: sender.index)
        
    }
    
    func numberOfRowsInSection()  -> Int{
        return todoList.count
    }
}
