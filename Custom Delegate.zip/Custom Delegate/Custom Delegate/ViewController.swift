//
//  ViewController.swift
//  Custom Delegate
//
//  Created by Naveen Madhu on 05/07/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var todoViewModel: TodoViewModel = TodoViewModel()
    var custom: CustomTableViewCell = CustomTableViewCell()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.delegate = self
        tableView.dataSource = self
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return todoViewModel.numberOfRowsInSection()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let todo = todoViewModel.todoList[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! CustomTableViewCell
        cell.titleLabel.text = todo.title
        cell.descriptionTextView.text = todo.describe
        cell.delegate = self
        cell.index = indexPath.row
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 240
    }
}

extension ViewController: CustomTableViewCellProtocol {
    
    // Updating the Array when button click
    func didEditOrSaveCell(_ sender: CustomTableViewCell) {
        // text, row number
        if sender.editButton.titleLabel?.text == "Save" {
            guard let title = sender.titleLabel.text, let description = sender.descriptionTextView.text else {return}
            let object = Todo(title: title, describe: description)
            todoViewModel.todoList.remove(at: sender.index)
            todoViewModel.todoList.insert(object, at: sender.index)
            sender.editButton.setTitle("Edit", for: .normal)
            sender.descriptionTextView.isEditable = false
        } else {
            sender.descriptionTextView.isEditable = true
            sender.editButton.setTitle("Save", for: .normal)
        }
    }
    
    // Deleting the cell when button click
    func didDeleteCell(_ sender: CustomTableViewCell) {
        if let indexpath = tableView.indexPath(for: sender) {
            self.todoViewModel.todoList.remove(at: indexpath.row)
            self.tableView.deleteRows(at: [indexpath], with: .automatic)
        }
    }
}

