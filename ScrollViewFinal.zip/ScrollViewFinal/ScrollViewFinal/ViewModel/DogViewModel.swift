//
//  DogViewModel.swift
//  ScrollViewFinal
//
//  Created by Naveen Madhu on 12/08/22.
//

import Foundation

class DogViewModel: NSObject {
    
    // Properties
    var dogList = Array<Dogs>()
    
    override init() {
        let dog1 = Dogs(dogImage: "pug", dogName: "Pug")
        let dog2 = Dogs(dogImage: "lab", dogName: "Labrador")
        let dog3 = Dogs(dogImage: "bull dog", dogName: "Bull Dog")
        let dog4 = Dogs(dogImage: "huskey", dogName: "Siberian Husky")
        let dog5 = Dogs(dogImage: "doberman", dogName: "Dobermann")
        let dog6 = Dogs(dogImage: "german shepherd", dogName: "German Shepherd")
        let dog7 = Dogs(dogImage: "golden retriver", dogName: "Golden Retriever")
        let dog8 = Dogs(dogImage: "pomorian", dogName: "Pomeranian")
        let dog9 = Dogs(dogImage: "rottwellier", dogName: "Rottweiler")
        let dog10 = Dogs(dogImage: "shihtzu", dogName: "Shih tzu")
        
        dogList.append(dog1)
        dogList.append(dog2)
        dogList.append(dog3)
        dogList.append(dog4)
        dogList.append(dog5)
        dogList.append(dog6)
        dogList.append(dog7)
        dogList.append(dog8)
        dogList.append(dog9)
        dogList.append(dog10)
    }
}
