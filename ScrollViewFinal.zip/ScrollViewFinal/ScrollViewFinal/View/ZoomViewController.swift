//
//  ZoomViewController.swift
//  ScrollViewFinal
//
//  Created by Naveen Madhu on 16/08/22.
//

import UIKit

class ZoomViewController: UIViewController {
    
    //MARK: IBOUTLET
    @IBOutlet weak var zoomScrollView: UIScrollView!
    @IBOutlet weak var zoomImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    
    // MARK: Stored Properties
    var image = UIImage()
    var name = ""
    
    //MARK: Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpScrollView()
        initialiseValue()
    }
    
    //MARK: IBAction
    @IBAction func backButtonPressed(_ sender: Any) {
        self.presentingViewController?.dismiss(animated: true)
    }
    
    // Initialising variables to the UI Elements
    func initialiseValue() {
        if let newImage = zoomImageView {
            newImage.image = image
        }
        if let newLabel = nameLabel {
            newLabel.text = name
        }
    }
    
    func setUpScrollView() {
        zoomScrollView.delegate = self
    }
}

//MARK: Scroll View Delegate 
extension ZoomViewController: UIScrollViewDelegate {
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return zoomImageView
    }
}
