//
//  ViewController.swift
//  ScrollViewFinal
//
//  Created by Naveen Madhu on 12/08/22.
//

import UIKit

class DogViewController: UIViewController {
    
    //MARK: IBOUTLET
    @IBOutlet weak var scrollView: UIScrollView!
    
    // MARK: Stored Properties
    private var dogViewModel: DogViewModel = DogViewModel()
    var xPosition = 0
    
    //MARK: Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupImageView()
    }
    
    // Adding image view in the scroll view
    func setupImageView() {
        for i in 0..<dogViewModel.dogList.count {
            let imageView = UIImageView()
            imageView.isUserInteractionEnabled = true
            imageView.tag = i
            imageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(imageTap(_:))))
            imageView.image = UIImage(named: dogViewModel.dogList[i].dogImage)
            imageView.contentMode = .scaleAspectFit
            imageView.frame = CGRect(x: CGFloat(xPosition), y: 0, width: self.scrollView.frame.width, height: 900)
            
            xPosition = xPosition + Int(scrollView.frame.width)
            scrollView.addSubview(imageView)
        }
        scrollView.contentSize = CGSize(width: xPosition, height: 200)
    }
    
    @objc func imageTap(_ sender: UITapGestureRecognizer) {
        let tag = sender.view?.tag
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ZoomViewController") as! ZoomViewController
        vc.image = UIImage(named: dogViewModel.dogList[tag ?? 0].dogImage)!
        vc.name = dogViewModel.dogList[tag ?? 0].dogName
        self.present(vc, animated: true)
    }
}
