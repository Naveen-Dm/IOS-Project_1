//
//  DogModel.swift
//  ScrollViewFinal
//
//  Created by Naveen Madhu on 12/08/22.
//

import Foundation

class Dogs: NSObject {
    let dogImage: String
    let dogName: String
    
    init(dogImage: String, dogName: String) {
        self.dogImage = dogImage
        self.dogName = dogName
    }
}
