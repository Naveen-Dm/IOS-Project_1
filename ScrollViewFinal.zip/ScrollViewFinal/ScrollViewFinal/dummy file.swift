////
////  dummy file.swift
////  ScrollViewFinal
////
////  Created by Naveen Madhu on 16/08/22.
////
//
//import Foundation
//import UIKit
//
//class ZoomViewController: UIViewController {
//
//    @IBOutlet weak var zoomScrollView: UIScrollView!
//    @IBOutlet weak var zoomImageView: UIImageView!
//    @IBOutlet weak var imageViewBottomConstraint: NSLayoutConstraint!
//    @IBOutlet weak var imageViewLeadingConstraint: NSLayoutConstraint!
//    @IBOutlet weak var imageViewTopConstraint: NSLayoutConstraint!
//    @IBOutlet weak var imageViewTrailingConstraint: NSLayoutConstraint!
//
//    var image = UIImage()
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        zoomScrollView?.delegate = self
//        zoomScrollView?.maximumZoomScale = 0.5
//
//        if let newImage = zoomImageView {
//            newImage.image = image
//        }
//    }
//
//    @IBAction func backButton(_ sender: Any) {
//        self.presentingViewController?.dismiss(animated: true)
//    }
//
//    func updateMinZoomScaleForSize(_ size: CGSize) {
//        let widthScale = size.width / zoomImageView.bounds.width
//        let heightScale = size.height / zoomImageView.bounds.height
//        let minScale = min(widthScale, heightScale)
//
//        zoomScrollView.minimumZoomScale = minScale
//        zoomScrollView.zoomScale = minScale
//    }
//
//    override func viewWillLayoutSubviews() {
//        super.viewWillLayoutSubviews()
//        updateMinZoomScaleForSize(view.bounds.size)
//    }
//
//}
//extension ZoomViewController: UIScrollViewDelegate {
//    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
//        return zoomImageView
//    }
//
//    func scrollViewDidZoom(_ scrollView: UIScrollView) {
//        updateConstraintsForSize(view.bounds.size)
//    }
//
//    func updateConstraintsForSize(_ size: CGSize) {
//        let yOffset = max(0, (size.height - zoomImageView.frame.height) / 2)
//        imageViewTopConstraint.constant = yOffset
//        imageViewBottomConstraint.constant = yOffset
//
//        let xOffset = max(0, (size.width - zoomImageView.frame.width) / 2)
//        imageViewLeadingConstraint.constant = xOffset
//        imageViewTrailingConstraint.constant = xOffset
//
//        view.layoutIfNeeded()
//    }
//}


// VIEWCONTROLLER (viewDidLoad)
//        var xposition = 0
//
//        for i in 0..<dogViewModel.dogList.count{
//            let imageView = UIImageView()
//            imageView.isUserInteractionEnabled = true
//            imageView.tag = i
//            imageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(imageTap(_:))))
//            imageView.image = UIImage(named: dogViewModel.dogList[i].dogImage)
//            imageView.contentMode = .scaleAspectFit
//            imageView.frame = CGRect(x: CGFloat(xposition), y: 0, width: self.scrollView.frame.width, height: 700)
//
//            xposition = xposition + Int(scrollView.frame.width)
//            scrollView.addSubview(imageView)
//        }
//        scrollView.contentSize = CGSize(width: xposition, height: 200)
