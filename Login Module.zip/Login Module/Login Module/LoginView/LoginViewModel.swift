//
//  LoginViewModel.swift
//  Login Module
//
//  Created by Naveen Madhu on 19/05/22.
//

import Foundation

 class LoginViewModel {
    
    var error: ObservableObject<String?> = ObservableObject(nil)
    
    func login(email:String, password:String) {
        NetworkService.shared.login(email: email, password: password) { [weak self] success in
            self?.error.value = success ? nil : "Invalid Credentials!!!"
        }
    }
}
