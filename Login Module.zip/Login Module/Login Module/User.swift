//
//  User.swift
//  Login Module
//
//  Created by Naveen Madhu on 19/05/22.
//

import Foundation

struct User {
    let firstName, lastName, email: String
    let age: Int
}
