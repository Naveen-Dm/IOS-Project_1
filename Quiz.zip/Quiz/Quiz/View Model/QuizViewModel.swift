//
//  QuizViewModel.swift
//  Quiz
//
//  Created by Naveen Madhu on 21/09/22.
//

import Foundation

class QuizViewModel {
    
//    var quiz = Array<Question>()
//
//    override init() {
//        let question1 = Question(question: "A slug's blood is green.", answer: "True")
//        let question2 = Question(question: "Approximately one quarter of human bones are in the feet.", answer: "True")
//        let question3 = Question(question: "The total surface area of two human lungs is approximately 70 square metres.", answer: "True")
//        let question4 = Question(question: "In West Virginia, USA, if you accidentally hit an animal with your car, you are free to take it home to eat.", answer: "True")
//        let question5 = Question(question: "In London, UK, if you happen to die in the House of Parliament, you are technically entitled to a state funeral, because the building is considered too sacred a place.", answer: "False")
//        let question6 = Question(question: "It is illegal to pee in the Ocean in Portugal.", answer: "True")
//        let question7 = Question(question: "You can lead a cow down stairs but not up stairs.", answer: "False")
//        let question8 = Question(question: "Google was originally called 'Backrub'.", answer: "True")
//        let question9 = Question(question: "Buzz Aldrin's mother's maiden name was 'Moon'.", answer: "True")
//        let question10 = Question(question: "The loudest sound produced by any animal is 188 decibels. That animal is the African Elephant.", answer: "False")
//        let question11 = Question(question: "No piece of square dry paper can be folded in half more than 7 times.", answer: "False")
//        let question12 = Question(question: "Chocolate affects a dog's heart and nervous system; a few ounces are enough to kill a small dog.", answer: "True")
//
//        quiz.append(question1)
//        quiz.append(question2)
//        quiz.append(question3)
//        quiz.append(question4)
//        quiz.append(question5)
//        quiz.append(question6)
//        quiz.append(question7)
//        quiz.append(question8)
//        quiz.append(question9)
//        quiz.append(question10)
//        quiz.append(question11)
//        quiz.append(question12)
//    }

        
    
    let quiz = [
        Question(question: "A slug's blood is green.", answer: "True"),
        Question(question: "Approximately one quarter of human bones are in the feet.", answer: "True"),
        Question(question: "The total surface area of two human lungs is approximately 70 square metres.", answer: "True"),
        Question(question: "In West Virginia, USA, if you accidentally hit an animal with your car, you are free to take it home to eat.", answer: "True"),
        Question(question: "In London, UK, if you happen to die in the House of Parliament, you are technically entitled to a state funeral, because the building is considered too sacred a place.", answer: "False"),
        Question(question: "It is illegal to pee in the Ocean in Portugal.", answer: "True"),
        Question(question: "You can lead a cow down stairs but not up stairs.", answer: "False"),
        Question(question: "Google was originally called 'Backrub'.", answer: "True"),
        Question(question: "Buzz Aldrin's mother's maiden name was 'Moon'.", answer: "True"),
        Question(question: "The loudest sound produced by any animal is 188 decibels. That animal is the African Elephant.", answer: "False"),
        Question(question: "No piece of square dry paper can be folded in half more than 7 times.", answer: "False"),
        Question(question: "Chocolate affects a dog's heart and nervous system; a few ounces are enough to kill a small dog.", answer: "True")

    ]
    
    var questionNumber = 0
    var score = 0
    
    func checkAnswer(_ userAnswer: String) -> Bool {
        if userAnswer == quiz[questionNumber].answer {
            score += 1
            return true
        } else {
            return false
        }
    }
    
    func getScore() -> Int {
        return score
    }
    
    func getQuestionText() -> String {
        return quiz[questionNumber].text
    }
    
    func getProgress() -> Float {
        let progress = Float(questionNumber) / Float(quiz.count)
        return progress
    }
    
    func nextQuestion() {
        if questionNumber + 1 < quiz.count {
            questionNumber += 1
        } else {
            questionNumber = 0
            score = 0
        }
    }
}
