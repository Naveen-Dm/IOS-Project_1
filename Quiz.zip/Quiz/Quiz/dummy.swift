//
//  dummy.swift
//  Quiz
//
//  Created by Naveen Madhu on 23/09/22.
//

import Foundation

//
//@IBAction func answerButtonPressed(_ sender: UIButton) {
//    
//    let userAnswer = sender.currentTitle!
//    let userGotItRight =  quizBrain.checkAnswer(userAnswer)
//    
//    if userGotItRight {
//        sender.backgroundColor = UIColor.green
//    } else {
//        sender.backgroundColor = UIColor.red
//    }
//    
//    quizBrain.nextQuestion()
//    
//    Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(updateUI), userInfo: nil, repeats: false)
//    
//}
//
//@objc func updateUI() {
//    questionLabel.text = quizBrain.getQuestionText()
//    progressBar.progress = quizBrain.getProgress()
//    scoreLabel.text = "Score: \(quizBrain.getScore())"
//    trueButton.backgroundColor = UIColor.clear
//    falseButton.backgroundColor = UIColor.clear
//}
