//
//  LoginViewModel.swift
//  login mvvm final
//
//  Created by Naveen Madhu on 19/05/22.
//


import Foundation

class LoginViewModel {
    //Here our model notify that was updated
    private var credentials : Credentials = Credentials() {
        didSet {
            username = credentials.username
            password = credentials.password
        }
    }
    
    private var username = ""
    private var password = ""
    //Login credentials
    private let usernameCheck = "Naveen"
    private let passwordCheck = "abc123"
    //Error messages
    private let loginSuccess = "Login Successful."
    private let invalidLogin = "Invalid Username or Password."
    private let textfieldsEmpty = "Please provide username and password."
    private let usernameIsEmpty = "Username field is empty."
    private let passwordIsEmpty = "Password field is empty."
    
    var credentialsInputErrorMessage: Observable<String> = Observable("")
    var isUsernameTextFieldHighLighted: Observable<Bool> = Observable(false)
    var isPasswordTextFieldHighLighted: Observable<Bool> = Observable(false)
    var errorMessage: Observable<String?> = Observable(nil)
    
    //Here we update our model
    func updateCredentials(username: String, password: String) {
        credentials.username = username
        credentials.password = password
    }
    
    //Validate the login credentials
    func login() {
        if (username == usernameCheck) && (password == passwordCheck) {
            credentialsInputErrorMessage.value = loginSuccess
        } else {
            credentialsInputErrorMessage.value = invalidLogin
        }
    }
    
    //Checks the user credentials input
    func credentialsInput() -> CredentialsInputStatus {
        if username.isEmpty && password.isEmpty {
            credentialsInputErrorMessage.value = textfieldsEmpty
            return.Incorrect
        }
        if username.isEmpty {
            credentialsInputErrorMessage.value = usernameIsEmpty
            isUsernameTextFieldHighLighted.value = true
            return.Incorrect
        }
        if password.isEmpty {
            credentialsInputErrorMessage.value = passwordIsEmpty
            isPasswordTextFieldHighLighted.value = true
            return.Incorrect
        }
        return.Correct
    }
}

extension LoginViewModel {
    enum CredentialsInputStatus {
        case Correct
        case Incorrect
    }
}
