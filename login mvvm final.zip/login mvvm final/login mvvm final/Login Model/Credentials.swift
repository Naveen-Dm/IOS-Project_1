//
//  Credentials.swift
//  login mvvm final
//
//  Created by Naveen Madhu on 19/05/22.
//

import Foundation

struct Credentials {
    var username: String = ""
    var password: String = ""
}
