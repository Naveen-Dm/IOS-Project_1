//
//  ViewController.swift
//  ScrollViewImage
//
//  Created by Naveen Madhu on 08/08/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var imageView: UIImageView!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        scrollView.delegate = self
        scrollView.maximumZoomScale = 5.0
    }

}

extension ViewController: UIScrollViewDelegate {
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imageView
    }
    
//    func scrollViewDidZoom(_ scrollView: UIScrollView) {
//        recenterImage(view.bounds.size)
//    }
}






















//
//@IBOutlet weak var imageViewBottomConstraint: NSLayoutConstraint!
//@IBOutlet weak var imageViewLeadingConstraint: NSLayoutConstraint!
//@IBOutlet weak var imageViewTopConstraint: NSLayoutConstraint!
//@IBOutlet weak var imageViewTrailingConstraint: NSLayoutConstraint!

//    func recenterImage(_ size: CGSize) {
//        let yOffset = max(0, (size.height - imageView.frame.height) / 2)
//        imageViewTopConstraint.constant = yOffset
//        imageViewBottomConstraint.constant = yOffset
//
//        let xOffset = max(0, (size.width - imageView.frame.width) / 2)
//        imageViewLeadingConstraint.constant = xOffset
//        imageViewTrailingConstraint.constant = xOffset
//
//        view.layoutIfNeeded()
//
//    }
